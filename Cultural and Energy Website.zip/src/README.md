# 🎨 Website Budaya Lokal dan Energi Alternatif Yogyakarta

Website ini menampilkan informasi lengkap tentang budaya lokal dan pengembangan energi alternatif di Daerah Istimewa Yogyakarta dengan **DESAIN SUPER POP & FUN** ala Canva! 🎉✨

## ✨ Fitur Utama

### 🎭 Budaya Lokal
- **🗣️ Tradisi Lisan**: Cublak Cublak Suweng, Boso Bagongan
- **💃 Seni Tari**: Tari Wira Pertiwi, Tari Kuda Kuda
- **🍜 Kuliner**: Kopi Joss, Gudeg
- **🎨 Kerajinan**: Gerobak Sapi, Batik Yogyakarta
- **🎉 Tradisi**: Sekaten
- **🏛️ Wisata Budaya**: Keraton Yogyakarta, Candi Prambanan (termasuk Sendratari Ramayana), Malioboro, Museum Sonobudoyo, Sentra Batik

### ⚡ Energi Alternatif
- **☀️ Energi Surya**: Solar photovoltaic untuk penerangan jalan dan kegiatan ekonomi
- **🌿 Biomassa**: Pemanfaatan limbah organik untuk energi
- **💨 Angin**: Turbin angin untuk daerah pesisir dan dataran tinggi
- **💧 Air**: Mikrohidro untuk desa-desa terpencil

Contoh implementasi di Gunungkidul dan kampus-kampus besar (UGM, UNY, UMY, UKDW)! 🎓

## 🎪 Desain Super Keren!

### 🌈 Warna-Warni Pop!
- Background gradient colorful (pink, purple, indigo)
- Setiap section punya warna gradient sendiri yang cerah!
- Card dengan border putih tebal dan shadow keren
- Emoji di mana-mana untuk vibes yang fun! 😄

### 🎭 Animasi Wayang Keren!
- **Wayang Gunungan** yang floating di kiri-kanan dengan animasi naik-turun dan rotasi smooth! 
- **Wayang Orang** di pojok bawah yang bergerak kiri-kanan dengan efek rotasi!
- Semua wayang punya drop shadow yang dramatic!

### ✨ Animasi & Efek:
- **Floating sparkles** yang naik-turun di background
- **Animated shapes** berputar dan scale up-down
- **Music visualizer** dengan bars yang naik-turun saat musik play!
- **Floating icons** (Heart, Star, Zap, Sparkles) di sekitar title
- **Hover effects** yang bikin card scale up dan rotate sedikit
- **Sticker "KLIK!" ** muncul saat hover di card
- **Corner decorations** berbentuk triangle warna-warni

### 🎵 Musik Gamelan Interaktif:
- Tombol musik super fun dengan gradient pink-red-yellow
- Icon berputar dengan animasi smooth saat play/pause
- Music visualizer dengan 5 bars yang bounce!
- Border putih tebal dan shadow besar

## 🎮 Cara Menggunakan

1. **Halaman Utama**: Lihat galeri card warna-warni semua item budaya dan energi!
2. **Hover Card**: Lihat efek zoom, rotate, dan sticker "KLIK!" muncul! 👆
3. **Klik Item**: Buka halaman detail dengan hero image keren dan gradient overlay!
4. **Musik Gamelan**: Klik tombol musik bulat warna-warni di pojok kanan atas! 🎵
5. **Navigasi**: Tombol "Kembali" dengan gradient dan animasi sparkles!
6. **Scroll to Top**: Tombol emoji ⬆️ di pojok kanan bawah untuk scroll ke atas!

## 🎨 Style & Vibes

Desain ini terinspirasi dari **Canva** dengan:
- 🌈 Warna-warna cerah dan gradient yang eye-catching
- 🎯 Typography bold dan fun dengan text shadow
- 🎪 Shapes dan borders yang playful
- ✨ Banyak emoji dan icons untuk vibes yang cheerful
- 🎭 Animasi smooth yang bikin website hidup!
- 🎨 Background blur dan glassmorphism effects
- 🌟 Stickers dan badges yang colorful

## 🚀 Teknologi

Website ini dibangun menggunakan:
- **React + TypeScript** - Framework modern
- **Tailwind CSS** - Utility-first CSS framework
- **Motion (Framer Motion)** - Animasi smooth & interactive
- **YouTube IFrame API** - Musik gamelan dengan kontrol interaktif
- **Unsplash** - Gambar berkualitas tinggi HD

## 🎉 Special Features

- **Animated Wayang Decorations** - Wayang Gunungan & Wayang Orang yang bergerak!
- **Colorful Gradient Cards** - Setiap card punya warna berbeda!
- **Music Visualizer** - Bars yang bounce mengikuti musik!
- **Floating Elements** - Sparkles, hearts, stars yang terbang!
- **3D Transform Effects** - Rotate dan scale saat hover!
- **Emoji Everywhere** - Bikin website lebih fun dan relatable untuk remaja!

---

**Made with 💖 and lots of ✨ for Yogyakarta!** 🎭🌈
