import { motion } from 'motion/react';
import { ArrowLeft, BookOpen, History, Sparkles, Heart, Star } from 'lucide-react';
import { culturalItems } from '../data/culturalData';

interface DetailPageProps {
  itemId: string;
  onBack: () => void;
}

const sectionColors = [
  'from-pink-400 to-rose-500',
  'from-purple-400 to-indigo-500',
  'from-cyan-400 to-blue-500',
  'from-yellow-400 to-orange-500',
  'from-green-400 to-emerald-500',
];

export function DetailPage({ itemId, onBack }: DetailPageProps) {
  const item = culturalItems.find((i) => i.id === itemId);

  if (!item) {
    return (
      <div className="container mx-auto px-4 py-12">
        <button
          onClick={onBack}
          className="mb-8 flex items-center gap-2 text-white hover:text-pink-300 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Kembali
        </button>
        <p className="text-white">Item tidak ditemukan</p>
      </div>
    );
  }

  const getCategoryColor = () => {
    const categories = ['tradisi-lisan', 'seni-tari', 'kuliner', 'kerajinan', 'tradisi', 'wisata', 'energi'];
    const index = categories.indexOf(item.category);
    return sectionColors[index % sectionColors.length];
  };

  const colorGradient = getCategoryColor();

  return (
    <div className="min-h-screen py-12 sm:py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl">
        {/* Fun Back Button */}
        <motion.button
          initial={{ opacity: 0, x: -50, scale: 0.8 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          whileHover={{ scale: 1.1, x: -5 }}
          whileTap={{ scale: 0.9 }}
          onClick={onBack}
          className={`mb-10 flex items-center gap-3 bg-gradient-to-r ${colorGradient} text-white px-8 py-4 rounded-full transition-all duration-300 shadow-2xl border-4 border-white font-bold text-lg group`}
        >
          <motion.div
            animate={{ x: [-2, 2, -2] }}
            transition={{ duration: 1, repeat: Infinity }}
          >
            <ArrowLeft className="w-6 h-6" />
          </motion.div>
          Kembali ke Halaman Utama
          <Sparkles className="w-5 h-5 group-hover:rotate-180 transition-transform duration-500" />
        </motion.button>

        {/* Main Card with Pop Style */}
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.6, type: 'spring', bounce: 0.4 }}
          className="bg-white rounded-[3rem] overflow-hidden shadow-[0_30px_90px_rgba(0,0,0,0.3)] border-8 border-white relative"
        >
          {/* Floating decorations */}
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              animate={{
                y: [0, -20, 0],
                rotate: [0, 360],
              }}
              transition={{
                duration: 3 + i,
                repeat: Infinity,
                delay: i * 0.5,
              }}
              className="absolute pointer-events-none z-30"
              style={{
                left: `${10 + i * 20}%`,
                top: `${5 + i * 3}%`,
              }}
            >
              {i % 2 === 0 ? (
                <Heart className="w-6 h-6 text-pink-400 opacity-40" />
              ) : (
                <Star className="w-6 h-6 text-yellow-400 opacity-40" />
              )}
            </motion.div>
          ))}

          {/* Hero Image with Fun Overlay */}
          <div className="aspect-video sm:aspect-[21/9] overflow-hidden relative">
            <img
              src={item.image}
              alt={item.name}
              className="w-full h-full object-cover"
            />
            
            {/* Colorful gradient overlay */}
            <div className={`absolute inset-0 bg-gradient-to-t ${colorGradient} opacity-40 mix-blend-multiply`}></div>
            
            {/* Fun title badge */}
            <motion.div
              initial={{ scale: 0, rotate: -45 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.3, type: 'spring', bounce: 0.6 }}
              className="absolute top-8 left-8 z-20"
            >
              <div className={`bg-gradient-to-r ${colorGradient} px-6 py-3 rounded-full shadow-2xl border-4 border-white`}>
                <p className="text-white font-black text-sm sm:text-base uppercase tracking-wider">
                  {item.category.replace('-', ' ')} 🎨
                </p>
              </div>
            </motion.div>

            {/* Big Title with Pop Style */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="absolute bottom-8 left-8 right-8 z-20"
            >
              <motion.h1
                animate={{
                  textShadow: [
                    '4px 4px 0px rgba(0,0,0,0.3)',
                    '6px 6px 0px rgba(0,0,0,0.3)',
                    '4px 4px 0px rgba(0,0,0,0.3)',
                  ],
                }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-5xl sm:text-6xl lg:text-7xl font-black text-white drop-shadow-2xl"
              >
                {item.name}
              </motion.h1>
            </motion.div>
          </div>

          {/* Content with Fun Sections */}
          <div className="p-8 sm:p-12 lg:p-16 space-y-12 bg-gradient-to-br from-pink-50 to-purple-50">
            {/* Description Section */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="relative"
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                className={`bg-gradient-to-r ${colorGradient} text-white p-6 rounded-3xl shadow-xl mb-6 border-4 border-white flex items-center gap-4`}
              >
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
                  className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm"
                >
                  <BookOpen className="w-8 h-8" />
                </motion.div>
                <h2 className="text-3xl sm:text-4xl font-black flex-1">
                  📖 Pengertian
                </h2>
                <Sparkles className="w-8 h-8" />
              </motion.div>
              
              <div className="bg-white rounded-3xl p-8 sm:p-10 border-4 border-gray-200 shadow-lg">
                <div className="text-gray-800 leading-relaxed space-y-5 text-base sm:text-lg">
                  {item.description.split('\n\n').map((paragraph, index) => (
                    <motion.p
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.6 + index * 0.1, duration: 0.5 }}
                      className="relative pl-6 border-l-4 border-pink-400"
                    >
                      {paragraph}
                    </motion.p>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* History Section */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.7, duration: 0.6 }}
              className="relative"
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                className={`bg-gradient-to-r ${colorGradient} text-white p-6 rounded-3xl shadow-xl mb-6 border-4 border-white flex items-center gap-4`}
              >
                <motion.div
                  animate={{ 
                    rotate: [0, -10, 10, 0],
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="bg-white/20 p-4 rounded-2xl backdrop-blur-sm"
                >
                  <History className="w-8 h-8" />
                </motion.div>
                <h2 className="text-3xl sm:text-4xl font-black flex-1">
                  📜 Sejarah
                </h2>
                <Star className="w-8 h-8" />
              </motion.div>
              
              <div className="bg-white rounded-3xl p-8 sm:p-10 border-4 border-gray-200 shadow-lg">
                <div className="text-gray-800 leading-relaxed space-y-5 text-base sm:text-lg">
                  {item.history.split('\n\n').map((paragraph, index) => (
                    <motion.p
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.8 + index * 0.1, duration: 0.5 }}
                      className="relative pl-6 border-l-4 border-purple-400"
                    >
                      {paragraph}
                    </motion.p>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>

          {/* Fun Bottom Border */}
          <div className={`h-6 bg-gradient-to-r ${colorGradient}`}>
            <motion.div
              animate={{
                x: ['0%', '100%', '0%'],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: 'linear',
              }}
              className="h-full w-20 bg-white/30"
            ></motion.div>
          </div>
        </motion.div>

        {/* Fun floating button to scroll up */}
        <motion.button
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1, type: 'spring', bounce: 0.6 }}
          whileHover={{ scale: 1.2, rotate: 10 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className={`fixed bottom-8 right-8 bg-gradient-to-r ${colorGradient} text-white p-5 rounded-full shadow-2xl border-4 border-white z-50`}
        >
          <motion.div
            animate={{ y: [-3, 3, -3] }}
            transition={{ duration: 1, repeat: Infinity }}
          >
            ⬆️
          </motion.div>
        </motion.button>
      </div>
    </div>
  );
}
