import { motion } from 'motion/react';
import { culturalItems } from '../data/culturalData';
import { Sparkles, Heart, Star, Zap } from 'lucide-react';

interface HomePageProps {
  onSelectItem: (id: string) => void;
}

const floatingIcons = [Heart, Star, Zap, Sparkles];

export function HomePage({ onSelectItem }: HomePageProps) {
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
      {/* Super Fun Header */}
      <motion.header
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, type: 'spring', bounce: 0.5 }}
        className="text-center mb-20 relative"
      >
        {/* Floating shapes around title */}
        {[...Array(8)].map((_, i) => {
          const Icon = floatingIcons[i % floatingIcons.length];
          return (
            <motion.div
              key={i}
              animate={{
                y: [0, -20, 0],
                rotate: [0, 360],
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: 3 + i * 0.5,
                repeat: Infinity,
                delay: i * 0.2,
              }}
              className="absolute pointer-events-none"
              style={{
                left: `${10 + i * 10}%`,
                top: `${i % 2 === 0 ? '0%' : '80%'}`,
              }}
            >
              <Icon className={`w-8 h-8 ${i % 4 === 0 ? 'text-pink-300' : i % 4 === 1 ? 'text-yellow-300' : i % 4 === 2 ? 'text-cyan-300' : 'text-purple-300'}`} />
            </motion.div>
          );
        })}

        <motion.div
          animate={{
            rotate: [0, 5, -5, 0],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="inline-block bg-white/20 backdrop-blur-lg border-4 border-white rounded-3xl px-12 py-8 mb-8 shadow-2xl"
        >
          <div className="flex items-center justify-center gap-4 mb-4">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
            >
              <Sparkles className="w-10 h-10 text-yellow-300" />
            </motion.div>
            <h1 className="text-6xl sm:text-7xl lg:text-8xl font-black bg-gradient-to-r from-yellow-300 via-pink-300 to-purple-300 bg-clip-text text-transparent drop-shadow-lg">
              YOGYAKARTA
            </h1>
            <motion.div
              animate={{ rotate: -360 }}
              transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
            >
              <Sparkles className="w-10 h-10 text-pink-300" />
            </motion.div>
          </div>
          <motion.p
            animate={{
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
            }}
            className="text-2xl sm:text-3xl font-bold text-white drop-shadow-lg"
          >
            🎨 Budaya & 🌱 Energi Alternatif
          </motion.p>
        </motion.div>

        <motion.div
          animate={{
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
          }}
          className="inline-block bg-gradient-to-r from-cyan-400 to-blue-500 text-white px-8 py-3 rounded-full text-xl font-bold shadow-lg"
        >
          ✨ Daerah Istimewa Yogyakarta ✨
        </motion.div>
      </motion.header>

      {/* Tradisi Lisan Section */}
      <FunSection 
        title="🗣️ Tradisi Lisan" 
        emoji="🎭"
        color="from-pink-400 to-rose-500"
        delay={0.1}
      >
        <ItemGrid category="tradisi-lisan" onSelectItem={onSelectItem} />
      </FunSection>

      {/* Seni Tari Section */}
      <FunSection 
        title="💃 Seni Tari" 
        emoji="🎪"
        color="from-purple-400 to-indigo-500"
        delay={0.15}
      >
        <ItemGrid category="seni-tari" onSelectItem={onSelectItem} />
      </FunSection>

      {/* Kuliner Section */}
      <FunSection 
        title="🍜 Kuliner Tradisional" 
        emoji="☕"
        color="from-orange-400 to-red-500"
        delay={0.2}
      >
        <ItemGrid category="kuliner" onSelectItem={onSelectItem} />
      </FunSection>

      {/* Kerajinan Section */}
      <FunSection 
        title="🎨 Keterampilan & Kerajinan" 
        emoji="✂️"
        color="from-teal-400 to-cyan-500"
        delay={0.25}
      >
        <ItemGrid category="kerajinan" onSelectItem={onSelectItem} />
      </FunSection>

      {/* Tradisi & Festival Section */}
      <FunSection 
        title="🎉 Tradisi & Festival" 
        emoji="🎊"
        color="from-yellow-400 to-amber-500"
        delay={0.3}
      >
        <ItemGrid category="tradisi" onSelectItem={onSelectItem} />
      </FunSection>

      {/* Wisata Budaya Section */}
      <FunSection 
        title="🏛️ Wisata Budaya" 
        emoji="🗿"
        color="from-emerald-400 to-green-500"
        delay={0.35}
      >
        <ItemGrid category="wisata" onSelectItem={onSelectItem} />
      </FunSection>

      {/* Energi Alternatif Section */}
      <FunSection 
        title="⚡ Pengembangan Energi Alternatif" 
        emoji="🌱"
        color="from-blue-400 to-indigo-500"
        delay={0.4}
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {culturalItems
            .filter((item) => item.category === 'energi')
            .map((item, index) => (
              <ItemCard key={item.id} item={item} onClick={onSelectItem} index={index} />
            ))}
        </div>
      </FunSection>
    </div>
  );
}

interface FunSectionProps {
  title: string;
  emoji: string;
  color: string;
  delay: number;
  children: React.ReactNode;
}

function FunSection({ title, emoji, color, delay, children }: FunSectionProps) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 50, scale: 0.9 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ duration: 0.6, delay, type: 'spring', bounce: 0.4 }}
      className="mb-24"
    >
      <motion.div
        whileHover={{ scale: 1.05 }}
        className={`bg-gradient-to-r ${color} text-white p-6 rounded-3xl shadow-2xl mb-10 border-4 border-white relative overflow-hidden`}
      >
        {/* Animated emoji */}
        <motion.div
          animate={{
            rotate: [0, 10, -10, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
          }}
          className="absolute right-8 top-1/2 -translate-y-1/2 text-6xl opacity-30"
        >
          {emoji}
        </motion.div>
        
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-center drop-shadow-lg relative z-10">
          {title}
        </h2>
      </motion.div>
      {children}
    </motion.section>
  );
}

interface ItemGridProps {
  category: string;
  onSelectItem: (id: string) => void;
}

function ItemGrid({ category, onSelectItem }: ItemGridProps) {
  const items = culturalItems.filter((item) => item.category === category);
  
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
      {items.map((item, index) => (
        <ItemCard key={item.id} item={item} onClick={onSelectItem} index={index} />
      ))}
    </div>
  );
}

interface ItemCardProps {
  item: {
    id: string;
    name: string;
    image: string;
    category: string;
  };
  onClick: (id: string) => void;
  index: number;
}

const cardColors = [
  'from-pink-400 to-rose-500',
  'from-purple-400 to-indigo-500',
  'from-cyan-400 to-blue-500',
  'from-yellow-400 to-orange-500',
  'from-green-400 to-emerald-500',
  'from-red-400 to-pink-500',
];

function ItemCard({ item, onClick, index }: ItemCardProps) {
  const colorGradient = cardColors[index % cardColors.length];

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
      whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1, type: 'spring', bounce: 0.5 }}
      whileHover={{ 
        scale: 1.08, 
        rotate: 2,
        y: -10,
      }}
      whileTap={{ scale: 0.95 }}
      onClick={() => onClick(item.id)}
      className="group cursor-pointer relative overflow-hidden rounded-3xl bg-white shadow-2xl border-4 border-white hover:shadow-[0_20px_60px_rgba(0,0,0,0.3)] transition-all duration-300"
    >
      {/* Colorful gradient overlay */}
      <div className={`absolute inset-0 bg-gradient-to-br ${colorGradient} opacity-0 group-hover:opacity-20 transition-opacity duration-300 z-10`}></div>

      {/* Image Container */}
      <div className="aspect-[4/3] overflow-hidden relative">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover group-hover:scale-125 transition-transform duration-500"
        />
        
        {/* Fun sticker effect on hover */}
        <motion.div
          initial={{ scale: 0, rotate: -45 }}
          whileHover={{ scale: 1, rotate: 0 }}
          className={`absolute top-4 right-4 bg-gradient-to-br ${colorGradient} text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg z-20`}
        >
          KLIK! 👆
        </motion.div>
      </div>

      {/* Content with gradient */}
      <div className={`p-6 bg-gradient-to-br ${colorGradient} relative`}>
        {/* Sparkle decoration */}
        <motion.div
          animate={{
            rotate: 360,
            scale: [1, 1.3, 1],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
          }}
          className="absolute top-2 right-2"
        >
          <Sparkles className="w-5 h-5 text-white/50" />
        </motion.div>

        <h3 className="text-xl sm:text-2xl font-black text-white text-center drop-shadow-lg">
          {item.name}
        </h3>
        
        {/* Animated arrow on hover */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileHover={{ opacity: 1, x: 0 }}
          className="mt-3 flex items-center justify-center gap-2 text-white font-bold"
        >
          <span className="text-sm">Lihat Selengkapnya</span>
          <motion.span
            animate={{ x: [0, 5, 0] }}
            transition={{ duration: 1, repeat: Infinity }}
          >
            →
          </motion.span>
        </motion.div>
      </div>

      {/* Fun corner decorations */}
      <div className="absolute top-0 left-0 w-0 h-0 border-t-[30px] border-t-yellow-300 border-r-[30px] border-r-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
      <div className="absolute bottom-0 right-0 w-0 h-0 border-b-[30px] border-b-pink-300 border-l-[30px] border-l-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </motion.div>
  );
}
