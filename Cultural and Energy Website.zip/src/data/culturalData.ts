export interface CulturalItem {
  id: string;
  name: string;
  category: 'tradisi-lisan' | 'seni-tari' | 'kuliner' | 'kerajinan' | 'tradisi' | 'wisata' | 'energi';
  image: string;
  description: string;
  history: string;
}

export const culturalItems: CulturalItem[] = [
  // TRADISI LISAN
  {
    id: 'cublak-cublak-suweng',
    name: 'Cublak Cublak Suweng',
    category: 'tradisi-lisan',
    image: 'https://images.unsplash.com/photo-1626445829571-3c5d2131bb99?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lbGFuJTIwdHJhZGl0aW9uYWwlMjBtdXNpY3xlbnwxfHx8fDE3NjUyNjM0MTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Cublak Cublak Suweng adalah sebuah lagu dolanan atau permainan tradisional anak-anak Jawa yang sangat populer di Yogyakarta dan seluruh Jawa Tengah. Permainan ini dimainkan secara berkelompok, biasanya oleh 5-10 anak, dengan satu orang menjadi "pak empo" yang harus menebak di tangan siapa sebuah batu atau biji-bijian kecil disembunyikan.

Lagu ini tidak hanya berfungsi sebagai hiburan, tetapi juga mengandung nilai-nilai pendidikan seperti kejujuran, sportivitas, dan kebersamaan. Lirik lagunya menggunakan bahasa Jawa khas yang sarat dengan filosofi kehidupan masyarakat agraris Jawa. Dalam konteks budaya Yogyakarta, Cublak Cublak Suweng menjadi bagian penting dari warisan budaya tak benda yang terus dilestarikan hingga kini.

Permainan ini biasanya diiringi dengan nyanyian yang memiliki melodi sederhana namun mudah diingat. Gerakan tangan yang kompak dari para pemain sambil menyanyikan lagu menciptakan keharmonisan dan kekompakan yang menjadi nilai utama dalam budaya Jawa.`,
    history: `Sejarah Cublak Cublak Suweng dipercaya berasal dari era Kerajaan Mataram Islam, sekitar abad ke-16 hingga ke-17. Lagu ini awalnya merupakan nyanyian rakyat yang digunakan untuk menghibur anak-anak petani ketika orang tua mereka bekerja di sawah. Kata "cublak" dalam bahasa Jawa berarti tidak ada atau hilang, sementara "suweng" berarti anting-anting.

Cerita yang berkembang di masyarakat menyebutkan bahwa lagu ini terinspirasi dari kehilangan anting-anting milik seorang bangsawan yang kemudian dicari oleh anak-anak kampung. Kisah tersebut kemudian diabadikan dalam bentuk permainan dan lagu yang terus diwariskan secara turun-temurun.

Pada masa kolonial Belanda, permainan ini tetap populer di kalangan anak-anak pribumi sebagai bentuk pelestarian budaya lokal. Setelah kemerdekaan Indonesia, pemerintah Daerah Istimewa Yogyakarta mulai mendokumentasikan dan memasukkan Cublak Cublak Suweng ke dalam kurikulum pendidikan seni dan budaya lokal.

Di era modern, berbagai komunitas dan lembaga budaya di Yogyakarta aktif mengadakan workshop dan festival dolanan anak untuk memastikan generasi muda tetap mengenal dan melestarikan permainan tradisional ini. Cublak Cublak Suweng juga telah direkam dalam berbagai format audio dan video sebagai dokumentasi warisan budaya tak benda UNESCO.`,
  },
  {
    id: 'boso-bagongan',
    name: 'Boso Bagongan',
    category: 'tradisi-lisan',
    image: 'https://images.unsplash.com/photo-1680144653445-9ea91934e5d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwbXVzZXVtJTIwaGVyaXRhZ2V8ZW58MXx8fHwxNzY1MjYzNDEzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Boso Bagongan atau yang juga dikenal sebagai Basa Walikan adalah bentuk bahasa Jawa khusus yang digunakan di Yogyakarta, khususnya di kawasan Malioboro dan sekitar Keraton. Bahasa ini merupakan bahasa "terbalik" atau bahasa sandi yang diciptakan dengan cara membalik suku kata atau menggunakan kode tertentu untuk menyembunyikan makna pembicaraan dari orang luar.

Boso Bagongan memiliki aturan-aturan khusus dalam pembentukannya, di mana huruf-huruf konsonan tertentu diganti dengan pasangannya. Misalnya, huruf 'b' menjadi 'g', 'd' menjadi 'k', dan seterusnya. Bahasa ini tidak hanya unik dari segi linguistik, tetapi juga mencerminkan kecerdasan dan kreativitas masyarakat Yogyakarta dalam menciptakan sistem komunikasi alternatif.

Penggunaan Boso Bagongan mencerminkan stratifikasi sosial dan fungsi komunikasi yang kompleks dalam masyarakat Yogyakarta. Bahasa ini menjadi identitas cultural yang kuat bagi komunitas tertentu, terutama para pedagang dan seniman jalanan di kawasan Malioboro.`,
    history: `Sejarah Boso Bagongan berawal dari masa perjuangan kemerdekaan Indonesia, khususnya pada periode agresi militer Belanda tahun 1945-1949. Ketika Yogyakarta menjadi ibu kota Republik Indonesia, para pejuang kemerdekaan membutuhkan bahasa sandi untuk berkomunikasi tanpa diketahui oleh tentara Belanda. Dari kebutuhan inilah Boso Bagongan diciptakan dan berkembang.

Awalnya, bahasa ini digunakan oleh kalangan istana dan pejuang kemerdekaan untuk menyampaikan pesan-pesan rahasia. Seiring waktu, penggunaannya meluas ke masyarakat umum, terutama di kalangan pedagang kaki lima di Malioboro. Para pedagang menggunakan bahasa ini untuk berkomunikasi dengan rekan sesama pedagang tanpa dimengerti oleh pembeli atau kompetitor.

Pada era 1970-an hingga 1990-an, Boso Bagongan mencapai puncak popularitasnya di kalangan anak muda Yogyakarta. Bahasa ini menjadi simbol identitas lokal dan kebanggaan sebagai warga Yogyakarta. Berbagai komunitas pemuda dan seniman menggunakan Boso Bagongan dalam percakapan sehari-hari dan karya seni mereka.

Pemerintah Kota Yogyakarta dan berbagai lembaga budaya kini aktif mendokumentasikan dan mengajarkan Boso Bagongan kepada generasi muda melalui berbagai program pendidikan dan workshop bahasa daerah. Upaya ini bertujuan untuk memastikan bahwa tradisi lisan unik ini tidak punah dan terus menjadi bagian dari identitas budaya Yogyakarta. Saat ini, Boso Bagongan juga mulai digunakan dalam media sosial dan aplikasi digital sebagai bentuk adaptasi modern dari tradisi lisan yang telah berusia hampir satu abad.`,
  },

  // SENI TARI
  {
    id: 'tari-wira-pertiwi',
    name: 'Tari Wira Pertiwi',
    category: 'seni-tari',
    image: 'https://images.unsplash.com/photo-1565792493552-39c3b0e40596?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMGluZG9uZXNpYW4lMjBkYW5jZXxlbnwxfHx8fDE3NjUyNjM0MTB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Tari Wira Pertiwi adalah tarian klasik Jawa yang diciptakan untuk menggambarkan kepahlawanan dan semangat juang dalam mempertahankan tanah air. Tarian ini menampilkan gerakan-gerakan dinamis dan penuh kekuatan yang melambangkan keberanian, ketegasan, dan patriotisme. Penari biasanya mengenakan kostum yang menyerupai pakaian prajurit keraton dengan aksesoris keris dan properti perang lainnya.

Tari Wira Pertiwi memiliki filosofi mendalam tentang konsep "wira" (pahlawan) dan "pertiwi" (tanah air atau bumi). Setiap gerakan dalam tarian ini sarat dengan makna simbolis yang menggambarkan perjuangan, pengorbanan, dan dedikasi untuk melindungi negeri. Gerakan tangan yang tegas, langkah kaki yang mantap, dan ekspresi wajah yang kuat menjadi ciri khas tarian ini.

Dalam pementasannya, Tari Wira Pertiwi diiringi oleh musik gamelan dengan tempo sedang hingga cepat, menciptakan suasana yang megah dan heroik. Tarian ini sering ditampilkan pada acara-acara kenegaraan, peringatan hari kemerdekaan, dan festival budaya sebagai simbol semangat nasionalisme dan cinta tanah air.`,
    history: `Tari Wira Pertiwi diciptakan pada era pasca kemerdekaan Indonesia, tepatnya pada tahun 1950-an oleh para empu tari Keraton Yogyakarta. Penciptaan tarian ini dilatarbelakangi oleh semangat nasionalisme yang tinggi setelah Indonesia meraih kemerdekaan dan Yogyakarta berperan besar sebagai ibu kota negara pada masa revolusi.

Pada awalnya, tarian ini dipersembahkan untuk menghormati para pahlawan yang gugur dalam perang kemerdekaan. Sultan Hamengku Buwono IX, yang dikenal sebagai sosok yang sangat mendukung seni dan budaya, memberikan dukungan penuh untuk pengembangan tarian ini di lingkungan keraton. Para koreografer istana menciptakan gerakan-gerakan yang terinspirasi dari tari-tari klasik Jawa seperti Tari Golek dan Tari Gambyong, namun dengan nuansa yang lebih gagah dan heroik.

Pada dekade 1960-an, Tari Wira Pertiwi mulai diajarkan di berbagai sanggar tari dan sekolah seni di Yogyakarta. Tarian ini menjadi materi wajib dalam kurikulum pendidikan seni tari klasik Jawa. Banyak seniman tari terkenal dari Yogyakarta yang kemudian mengembangkan variasi dan interpretasi baru dari Tari Wira Pertiwi, menjadikannya semakin kaya dan beragam.

Di era modern, Tari Wira Pertiwi terus dilestarikan dan ditampilkan dalam berbagai acara nasional dan internasional sebagai representasi budaya Indonesia. Institut Seni Indonesia (ISI) Yogyakarta dan berbagai lembaga kebudayaan aktif melakukan penelitian, dokumentasi, dan regenerasi penari-penari muda untuk memastikan tarian ini tetap hidup dan berkembang sesuai zaman tanpa kehilangan esensi dan nilai filosofisnya.`,
  },
  {
    id: 'tari-kuda-kuda',
    name: 'Tari Kuda Kuda',
    category: 'seni-tari',
    image: 'https://images.unsplash.com/photo-1565792493552-39c3b0e40596?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMGluZG9uZXNpYW4lMjBkYW5jZXxlbnwxfHx8fDE3NjUyNjM0MTB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Tari Kuda Kuda atau Tari Jaran Kepang adalah tarian tradisional Jawa yang menggambarkan atraksi pasukan berkuda dalam peperangan. Tarian ini menampilkan sekelompok penari yang membawa properti anyaman bambu berbentuk kuda, menggambarkan gerakan para prajurit menunggang kuda dengan gagah berani. Tari Kuda Kuda memiliki unsur magis dan spiritual yang kental, di mana para penari sering mengalami kesurupan atau trance sebagai bagian dari ritual pertunjukan.

Keunikan Tari Kuda Kuda terletak pada kombinasi antara seni tari, musik gamelan, dan unsur spiritual yang menciptakan pertunjukan yang sangat menarik dan mencekam. Penari mengenakan kostum prajurit dengan warna-warna cerah, dilengkapi dengan properti kuda yang terbuat dari anyaman bambu yang dihias dengan benang wol berwarna-warni dan kertas mengkilap.

Gerakan dalam Tari Kuda Kuda sangat energik dan dinamis, meniru gerakan kuda berlari, berjingkat, dan berputar. Para penari bergerak dengan cepat mengikuti irama musik gamelan yang dimainkan dengan tempo cepat dan penuh semangat. Pertunjukan ini tidak hanya menjadi tontonan yang menghibur, tetapi juga memiliki nilai spiritual dan ritual yang dipercaya dapat membawa berkah dan perlindungan.`,
    history: `Tari Kuda Kuda memiliki sejarah yang panjang dan berakar dari tradisi animisme dan Hindu-Buddha di Jawa. Tarian ini dipercaya telah ada sejak era Kerajaan Mataram Kuno, sekitar abad ke-8 hingga ke-10 Masehi. Pada masa itu, tarian dengan properti kuda digunakan dalam ritual-ritual keagamaan untuk menghormati dewa-dewa dan roh leluhur.

Pada era Kerajaan Mataram Islam, Tari Kuda Kuda mengalami transformasi dengan masuknya unsur-unsur Islam, namun tetap mempertahankan elemen-elemen spiritual dan magis dari tradisi sebelumnya. Tarian ini menjadi bagian dari upacara adat dan perayaan-perayaan besar di keraton dan desa-desa di sekitar Yogyakarta.

Pada masa kolonial Belanda, Tari Kuda Kuda sempat dilarang karena dianggap mengandung unsur tahayul dan dapat menimbulkan kerusuhan. Namun, masyarakat Jawa tetap melestarikan tarian ini secara diam-diam sebagai bentuk perlawanan budaya. Setelah kemerdekaan Indonesia, tarian ini kembali muncul ke permukaan dan mendapat apresiasi sebagai warisan budaya yang berharga.

Di Yogyakarta, Tari Kuda Kuda berkembang dengan berbagai variasi dan nama lokal seperti Jathilan atau Kuda Lumping. Setiap daerah memiliki karakteristik dan gaya pertunjukan yang sedikit berbeda, namun esensi dan filosofinya tetap sama. Pada tahun 1980-an hingga 1990-an, Tari Kuda Kuda mengalami revitalisasi besar-besaran dengan dukungan pemerintah daerah dan seniman-seniman muda yang ingin melestarikan tradisi leluhur.

Saat ini, Tari Kuda Kuda masih sering ditampilkan dalam berbagai acara seperti pernikahan, khitanan, syukuran, dan festival budaya. Banyak grup kesenian Jathilan yang aktif di Yogyakarta dan sekitarnya, melakukan pertunjukan secara reguler dan mengajarkan tarian ini kepada generasi muda. Pemerintah Daerah Istimewa Yogyakarta juga telah menetapkan Tari Kuda Kuda sebagai salah satu warisan budaya tak benda yang dilindungi dan dilestarikan.`,
  },

  // KULINER
  {
    id: 'kopi-joss',
    name: 'Kopi Joss',
    category: 'kuliner',
    image: 'https://images.unsplash.com/photo-1589476993333-f55b84301219?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwY29mZmVlJTIwa29waXxlbnwxfHx8fDE3NjUyNjM0MTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Kopi Joss adalah minuman kopi khas Yogyakarta yang sangat unik dan terkenal karena cara penyajiannya yang tidak biasa. Kopi ini disajikan dengan memasukkan arang bara panas yang membara langsung ke dalam gelas kopi yang baru diseduh, menciptakan suara "joss" atau "tssss" yang khas dan asap mengepul. Proses ini tidak hanya menciptakan efek visual yang menarik, tetapi juga dipercaya dapat mengurangi kadar asam dalam kopi sehingga lebih aman untuk lambung.

Rasa Kopi Joss sangat khas, dengan aroma smoky yang lembut dan rasa yang tidak terlalu asam. Kopi ini biasanya disajikan dengan gula batu atau gula pasir sesuai selera, dan diminum selagi masih hangat. Keunikan penyajian dengan arang membuat Kopi Joss menjadi salah satu ikon kuliner Yogyakarta yang wajib dicoba oleh wisatawan.

Kopi Joss biasanya dijual di angkringan atau warung kopi tradisional yang tersebar di berbagai sudut Yogyakarta, terutama di kawasan Tugu dan Malioboro. Harganya sangat terjangkau, menjadikannya minuman favorit tidak hanya untuk wisatawan tetapi juga untuk masyarakat lokal yang ingin menikmati kopi dengan cara yang berbeda.`,
    history: `Kopi Joss pertama kali diciptakan oleh Bapak Man, seorang penjual kopi keliling di kawasan Angkringan Lik Man, daerah Tugu, Yogyakarta, pada tahun 1960-an. Pada masa itu, Bapak Man mengalami masalah kesehatan berupa sakit maag yang cukup serius. Sebagai seorang penjual kopi, ia sangat menyukai kopi tetapi tidak bisa meminumnya karena asam kopi memperparah kondisi lambungnya.

Suatu hari, Bapak Man terinspirasi untuk mencoba memasukkan arang bara panas ke dalam kopi yang baru diseduh. Ide ini muncul dari kepercayaan tradisional bahwa arang dapat menyerap racun dan mengurangi kadar asam. Setelah mencoba, ia merasakan bahwa kopinya menjadi lebih lembut di lambung dan tidak menyebabkan sakit maag seperti sebelumnya. Dari eksperimen inilah, Kopi Joss lahir.

Awalnya, banyak orang yang skeptis dan takut mencoba kopi dengan arang, namun seiring waktu, keunikan dan rasa yang berbeda membuat Kopi Joss semakin populer. Pelanggan mulai berdatangan untuk mencoba minuman unik ini, dan reputasi Angkringan Lik Man sebagai tempat asal Kopi Joss mulai menyebar ke seluruh Yogyakarta.

Pada dekade 1990-an, Kopi Joss mulai dikenal secara luas di Indonesia melalui liputan media massa dan promosi pariwisata Yogyakarta. Banyak penjual kopi lain yang kemudian mengadopsi metode ini, dan Kopi Joss menjadi salah satu daya tarik kuliner khas Yogyakarta. Meskipun Bapak Man telah meninggal dunia, warisan kulinernya tetap hidup dan terus dilestarikan oleh keluarga dan para penerusnya.

Saat ini, Kopi Joss tidak hanya dapat ditemukan di Angkringan Lik Man, tetapi juga di berbagai angkringan dan kafe modern di seluruh Yogyakarta. Minuman ini telah menjadi bagian dari identitas kuliner Yogyakarta dan sering menjadi oleh-oleh atau pengalaman kuliner yang dicari oleh wisatawan domestik maupun mancanegara.`,
  },
  {
    id: 'gudeg',
    name: 'Gudeg',
    category: 'kuliner',
    image: 'https://images.unsplash.com/photo-1707529332935-bfa3925f15ac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxndWRlZyUyMHlvZ3lha2FydGF8ZW58MXx8fHwxNzY1MjYzNDA5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Gudeg adalah makanan tradisional khas Yogyakarta yang terbuat dari nangka muda yang dimasak dengan santan dan gula merah hingga berwarna cokelat kemerahan. Gudeg memiliki rasa manis yang khas dengan tekstur lembut dan aroma rempah-rempah yang menggugah selera. Makanan ini biasanya disajikan dengan nasi, ayam kampung, telur rebus, sambal goreng krecek (kulit sapi), dan tahu atau tempe bacem.

Proses memasak Gudeg membutuhkan waktu yang sangat lama, bisa mencapai 6 hingga 8 jam atau bahkan lebih, dengan api kecil agar nangka muda dapat meresap sempurna dengan bumbu dan santan. Bumbu yang digunakan meliputi daun salam, daun jati (yang memberikan warna khas), lengkuas, bawang putih, bawang merah, ketumbar, dan berbagai rempah tradisional lainnya.

Gudeg tidak hanya sekadar makanan, tetapi juga menjadi simbol budaya dan identitas masyarakat Yogyakarta. Makanan ini mencerminkan kesabaran dan ketelatenan dalam proses pembuatannya, nilai-nilai yang sangat dijunjung tinggi dalam budaya Jawa. Gudeg Yogyakarta juga terkenal dengan julukan "Gudeg Yogya" atau "Gudeg Mbah Lindu" yang menjadi ikon kuliner daerah ini.`,
    history: `Sejarah Gudeg diperkirakan sudah ada sejak era Kerajaan Mataram Islam pada abad ke-16 hingga ke-17. Pada masa itu, nangka muda yang melimpah di wilayah Yogyakarta diolah menjadi berbagai hidangan untuk memenuhi kebutuhan makanan masyarakat. Karena nangka mudah didapat dan tumbuh subur di iklim tropis, masyarakat menciptakan berbagai cara pengolahan, salah satunya adalah Gudeg.

Nama "Gudeg" sendiri konon berasal dari bahasa Jawa "hangudeg" yang berarti "menggodok" atau memasak dengan waktu lama. Ada juga yang menyebutkan bahwa nama ini berasal dari "degdegan" yang berarti deg-degan atau berdebar, merujuk pada proses menunggu yang lama saat memasak.

Pada masa pemerintahan Sultan Hamengku Buwono I, Gudeg mulai dikenal sebagai hidangan istimewa yang disajikan dalam acara-acara besar di keraton. Penggunaan daun jati dalam proses memasak Gudeg dipercaya dimulai pada masa ini, yang memberikan warna cokelat kemerahan yang khas dan menjadi ciri Gudeg Yogyakarta.

Pada era kolonial Belanda, Gudeg tetap menjadi makanan favorit masyarakat pribumi dan mulai dikenal oleh orang-orang Belanda yang tinggal di Yogyakarta. Setelah kemerdekaan Indonesia, Gudeg semakin populer dan mulai dijual secara komersial di berbagai warung dan rumah makan di Yogyakarta.

Pada tahun 1950-an hingga 1960-an, muncul berbagai pedagang Gudeg terkenal seperti Gudeg Yu Djum, Gudeg Bu Tjitro, dan Gudeg Wijilan yang hingga kini masih beroperasi dan menjadi legenda kuliner Yogyakarta. Masing-masing memiliki resep dan cita rasa yang sedikit berbeda, namun tetap mempertahankan karakteristik Gudeg Yogyakarta yang khas.

Di era modern, Gudeg telah menjadi salah satu ikon kuliner Indonesia yang dikenal hingga mancanegara. Pemerintah Daerah Istimewa Yogyakarta aktif mempromosikan Gudeg dalam berbagai event kuliner nasional dan internasional. Gudeg juga telah dikemas dalam bentuk instan dan kalengan untuk memudahkan distribusi ke berbagai daerah. Meskipun telah mengalami berbagai inovasi dan modernisasi, Gudeg tetap mempertahankan esensi dan kelezatan tradisionalnya yang menjadi kebanggaan masyarakat Yogyakarta.`,
  },

  // KERAJINAN
  {
    id: 'gerobak-sapi',
    name: 'Gerobak Sapi',
    category: 'kerajinan',
    image: 'https://images.unsplash.com/photo-1593216452146-1c47e42b2461?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaXRpb25hbCUyMG94JTIwY2FydHxlbnwxfHx8fDE3NjUyNjM0MTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Gerobak Sapi atau Andong adalah alat transportasi tradisional berupa kereta yang ditarik oleh sapi atau kerbau, yang menjadi salah satu ikon transportasi khas Yogyakarta. Gerobak ini terbuat dari kayu jati yang kuat dan tahan lama, dengan desain yang sederhana namun fungsional. Gerobak Sapi memiliki dua atau empat roda besar yang terbuat dari kayu atau besi, dengan tempat duduk yang dapat menampung 4-6 penumpang.

Pembuatan Gerobak Sapi merupakan kerajinan tangan yang membutuhkan keterampilan dan keahlian khusus. Para pengrajin menggunakan teknik tradisional dalam merakit dan mendekorasi gerobak, termasuk ukiran kayu yang indah pada bagian-bagian tertentu. Proses pembuatan satu gerobak bisa memakan waktu berminggu-minggu hingga berbulan-bulan, tergantung pada tingkat detail dan kualitas yang diinginkan.

Meskipun kini telah banyak digantikan oleh kendaraan bermotor modern, Gerobak Sapi masih dapat ditemukan di beberapa tempat wisata di Yogyakarta, terutama di kawasan Malioboro dan sekitar Keraton. Gerobak ini kini lebih banyak digunakan untuk wisata nostalgia dan sebagai atraksi budaya yang menarik bagi wisatawan.`,
    history: `Sejarah Gerobak Sapi di Yogyakarta dimulai pada era Kerajaan Mataram, sekitar abad ke-16 hingga ke-17, ketika alat transportasi beroda yang ditarik oleh hewan mulai digunakan untuk mengangkut barang dan penumpang. Pada masa itu, Gerobak Sapi menjadi alat transportasi utama bagi masyarakat biasa yang tidak memiliki kendaraan pribadi seperti dokar atau kuda.

Pada masa pemerintahan Kasultanan Yogyakarta, penggunaan Gerobak Sapi semakin meluas dan menjadi bagian penting dari sistem transportasi kota. Gerobak ini digunakan tidak hanya untuk mengangkut orang, tetapi juga untuk mengangkut hasil pertanian, barang dagangan, dan berbagai keperluan lainnya. Pembuatan gerobak menjadi profesi turun-temurun yang ditekuni oleh para pengrajin kayu di desa-desa sekitar Yogyakarta.

Pada era kolonial Belanda, Gerobak Sapi tetap menjadi moda transportasi favorit masyarakat pribumi. Beberapa pabrik gula dan perkebunan milik Belanda juga menggunakan Gerobak Sapi untuk mengangkut hasil panen ke gudang atau stasiun kereta api. Pada masa ini, desain dan konstruksi gerobak mengalami sedikit modifikasi dengan pengaruh teknologi Eropa, seperti penggunaan besi untuk memperkuat struktur roda dan rangka.

Setelah kemerdekaan Indonesia, terutama pada tahun 1950-an hingga 1970-an, Gerobak Sapi masih sangat populer sebagai alat transportasi sehari-hari di Yogyakarta. Namun, dengan masuknya becak, sepeda motor, dan mobil, penggunaan Gerobak Sapi mulai menurun drastis. Banyak pengrajin yang beralih profesi karena permintaan yang semakin berkurang.

Pada tahun 1990-an, pemerintah Daerah Istimewa Yogyakarta mulai menggalakkan program pelestarian budaya dengan merevitalisasi penggunaan Gerobak Sapi sebagai atraksi wisata. Beberapa gerobak dipugar dan dioperasikan kembali di kawasan wisata untuk memberikan pengalaman nostalgia kepada wisatawan. Hingga kini, Gerobak Sapi masih dapat ditemukan di beberapa lokasi wisata dan menjadi salah satu daya tarik budaya Yogyakarta.

Para pengrajin Gerobak Sapi juga mendapat dukungan dari pemerintah dan lembaga budaya untuk terus melestarikan keterampilan mereka. Workshop dan pelatihan pembuatan gerobak tradisional diadakan secara berkala untuk regenerasi pengrajin muda, memastikan bahwa keahlian ini tidak punah di tengah modernisasi.`,
  },
  {
    id: 'batik',
    name: 'Batik Yogyakarta',
    category: 'kerajinan',
    image: 'https://images.unsplash.com/photo-1604973104381-870c92f10343?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXRpayUyMGluZG9uZXNpYXxlbnwxfHx8fDE3NjUyNjM0MDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Batik Yogyakarta adalah salah satu warisan budaya Indonesia yang telah diakui oleh UNESCO sebagai Warisan Budaya Tak Benda Manusia pada tahun 2009. Batik Yogyakarta memiliki ciri khas dengan motif-motif geometris yang teratur dan simetris, dengan warna-warna natural seperti cokelat, putih gading, biru tua, dan hitam. Motif batik Yogyakarta sangat kaya dengan filosofi dan makna simbolis yang mendalam, mencerminkan nilai-nilai kehidupan masyarakat Jawa.

Proses pembuatan batik tradisional Yogyakarta menggunakan teknik tulis (batik tulis) dan cap (batik cap) dengan menggunakan canting untuk menggambar motif menggunakan malam (lilin) pada kain. Setelah proses pembatikan, kain dicelup dengan pewarna alami atau sintetis, kemudian malam dibersihkan dengan cara direbus. Proses ini bisa diulang beberapa kali untuk mendapatkan warna dan motif yang diinginkan.

Motif batik Yogyakarta yang terkenal antara lain Parang Rusak, Kawung, Truntum, Sido Mukti, dan Sido Luhur. Setiap motif memiliki makna dan filosofi yang berbeda, serta aturan penggunaan tertentu. Misalnya, motif Parang Rusak hanya boleh digunakan oleh keluarga keraton, sementara motif-motif tertentu digunakan untuk upacara pernikahan, khitanan, atau acara-acara adat lainnya.`,
    history: `Sejarah Batik di Yogyakarta tidak dapat dipisahkan dari sejarah Keraton Kasultanan Yogyakarta. Batik mulai berkembang pesat di Yogyakarta pada masa pemerintahan Sultan Hamengku Buwono I (1755-1792), pendiri Kasultanan Yogyakarta. Pada masa itu, batik menjadi bagian penting dari busana keraton dan simbol status sosial dalam masyarakat Jawa.

Pada era Kerajaan Mataram sebelumnya, batik sudah dikenal namun masih terbatas pada kalangan bangsawan dan kaum ningrat. Motif-motif tertentu seperti Parang dan Kawung ditetapkan sebagai motif larangan (motif yang hanya boleh digunakan oleh keluarga raja). Penetapan ini bertujuan untuk mempertahankan eksklusivitas dan kehormatan kerajaan.

Pada abad ke-19, terutama pada masa pemerintahan Sultan Hamengku Buwono VII dan VIII, batik Yogyakarta mengalami perkembangan pesat. Para putri dan permaisuri keraton sangat aktif dalam mengembangkan motif-motif baru dan teknik pembatikan. Mereka mendirikan workshop batik di dalam keraton dan mengajarkan keterampilan membatik kepada para abdi dalem dan masyarakat sekitar.

Pada masa kolonial Belanda, batik Yogyakarta mulai dikenal di kalangan Eropa dan menjadi komoditas ekspor yang berharga. Banyak pengusaha batik yang mulai bermunculan di luar keraton, membuka usaha batik komersial yang melayani pasar yang lebih luas. Kawasan-kawasan seperti Tirtodipuran dan Prawirotaman menjadi sentra produksi batik yang terkenal.

Setelah kemerdekaan Indonesia, industri batik Yogyakarta terus berkembang dengan dukungan pemerintah. Pada tahun 1970-an hingga 1980-an, batik Yogyakarta mengalami masa kejayaan dengan banyaknya pesanan dari dalam dan luar negeri. Namun, pada era 1990-an, industri batik mengalami penurunan akibat kompetisi dengan tekstil printing modern yang lebih murah dan cepat diproduksi.

Pengakuan UNESCO pada tahun 2009 memberikan angin segar bagi industri batik Yogyakarta. Pemerintah daerah dan berbagai lembaga budaya gencar mempromosikan batik dan mendorong masyarakat untuk menggunakan batik dalam kehidupan sehari-hari. Program-program pelatihan batik untuk generasi muda digalakkan, dan banyak desainer muda yang mulai mengeksplorasi batik dengan desain kontemporer.

Saat ini, Yogyakarta memiliki banyak sentra batik seperti Kampung Batik Giriloyo, Kampung Batik Wijilan, dan Sentra Batik Bantul yang menjadi destinasi wisata edukasi batik. Pengrajin batik Yogyakarta terus berinovasi dengan menciptakan produk-produk batik modern seperti tas, sepatu, aksesori, dan berbagai produk fashion yang menarik pasar muda dan internasional, sambil tetap mempertahankan kearifan lokal dan nilai-nilai tradisional.`,
  },

  // TRADISI
  {
    id: 'sekaten',
    name: 'Sekaten',
    category: 'tradisi',
    image: 'https://images.unsplash.com/photo-1626445829571-3c5d2131bb99?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lbGFuJTIwdHJhZGl0aW9uYWwlMjBtdXNpY3xlbnwxfHx8fDE3NjUyNjM0MTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Sekaten adalah upacara tradisional dan perayaan keagamaan Islam yang diselenggarakan setiap tahun di Keraton Yogyakarta untuk memperingati Maulid Nabi Muhammad SAW. Perayaan ini berlangsung selama satu minggu penuh, dimulai dari tanggal 5 hingga 12 Rabiul Awal (bulan ketiga dalam kalender Islam). Sekaten merupakan salah satu tradisi terbesar dan paling penting di Yogyakarta yang menggabungkan unsur keagamaan, budaya, dan hiburan rakyat.

Nama "Sekaten" berasal dari bahasa Arab "syahadatain" yang berarti dua kalimat syahadat. Perayaan ini mencakup berbagai kegiatan seperti pawai gamelan pusaka keraton (Gamelan Kyai Kanjeng Nogowilogo dan Kyai Kanjeng Guntur Madu), pameran hasil kerajinan dan produk lokal, pasar malam dengan berbagai kuliner khas, permainan tradisional, dan berbagai pertunjukan seni dan budaya.

Puncak acara Sekaten adalah upacara Grebeg Maulud, di mana gunungan (tumpeng raksasa yang terbuat dari hasil bumi dan makanan) dibawa dalam prosesi dari Keraton ke Masjid Agung Yogyakarta. Ribuan orang berebut untuk mendapatkan bagian dari gunungan karena dipercaya membawa berkah dan keberuntungan.`,
    history: `Sejarah Sekaten dimulai pada masa Kerajaan Demak, kerajaan Islam pertama di Jawa, pada abad ke-15. Perayaan ini diprakarsai oleh Sunan Kalijaga, salah satu Wali Songo yang berperan besar dalam penyebaran Islam di Jawa. Sunan Kalijaga menggunakan pendekatan budaya dalam berdakwah, dengan mengadaptasi tradisi dan seni lokal untuk menarik perhatian masyarakat yang masih menganut kepercayaan Hindu-Buddha dan animisme.

Sunan Kalijaga menciptakan Gamelan Sekaten, seperangkat gamelan pusaka dengan suara yang sangat merdu dan menggetarkan hati. Gamelan ini dimainkan di depan Masjid Agung Demak untuk menarik perhatian masyarakat agar datang dan mendengarkan ceramah agama Islam. Metode dakwah ini sangat efektif dan menjadi tradisi yang terus dilestarikan hingga kini.

Ketika Kerajaan Mataram Islam berdiri pada abad ke-16, tradisi Sekaten dibawa dan dikembangkan lebih lanjut oleh Sultan Agung Hanyokrokusumo. Pada masa pemerintahannya, Sekaten menjadi perayaan besar yang diselenggarakan dengan megah di Keraton Mataram. Gamelan pusaka keraton dimainkan, dan berbagai upacara adat dilaksanakan untuk memperingati kelahiran Nabi Muhammad SAW.

Setelah Kerajaan Mataram terpecah menjadi Kasunanan Surakarta dan Kasultanan Yogyakarta pada tahun 1755 (Perjanjian Giyanti), tradisi Sekaten tetap dilestarikan di kedua keraton. Di Yogyakarta, Sultan Hamengku Buwono I dan para penerusnya terus mengadakan upacara Sekaten setiap tahun dengan kemegahan yang tidak berkurang.

Pada masa kolonial Belanda, upacara Sekaten sempat dibatasi oleh pemerintah kolonial karena khawatir dapat menimbulkan perkumpulan massa yang besar. Namun, atas desakan Sultan dan masyarakat Yogyakarta, tradisi ini tetap diperbolehkan dengan pengawasan ketat.

Setelah kemerdekaan Indonesia, Sekaten kembali dirayakan dengan meriah dan menjadi salah satu agenda budaya tahunan yang penting di Yogyakarta. Pemerintah Daerah Istimewa Yogyakarta memberikan dukungan penuh untuk pelestarian tradisi ini, termasuk renovasi alun-alun dan fasilitas pendukung lainnya.

Pada era modern, Sekaten tidak hanya menjadi upacara keagamaan dan budaya, tetapi juga menjadi event wisata yang menarik ribuan wisatawan dari berbagai daerah dan mancanegara. Pasar malam Sekaten yang berlangsung di Alun-alun Utara menjadi daya tarik tersendiri dengan berbagai hiburan, kuliner, dan pertunjukan rakyat. Hingga kini, Sekaten tetap menjadi simbol kerukunan beragama dan kekayaan budaya Jawa yang harmonis antara nilai-nilai Islam dan tradisi lokal.`,
  },

  // WISATA BUDAYA
  {
    id: 'keraton-yogyakarta',
    name: 'Keraton Yogyakarta',
    category: 'wisata',
    image: 'https://images.unsplash.com/photo-1680143760469-77f7ab4c4b9b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b2d5YWthcnRhJTIwcGFsYWNlJTIwa2VyYXRvbnxlbnwxfHx8fDE3NjUyNjM0MDh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Keraton Ngayogyakarta Hadiningrat atau Keraton Yogyakarta adalah istana resmi Kasultanan Ngayogyakarta Hadiningrat yang terletak di pusat kota Yogyakarta. Keraton ini merupakan kompleks bangunan megah yang kaya akan nilai sejarah, budaya, dan arsitektur Jawa klasik. Sebagai pusat pemerintahan kesultanan yang masih berfungsi hingga saat ini, Keraton Yogyakarta menjadi simbol keberlangsungan tradisi dan budaya Jawa di era modern.

Kompleks Keraton terdiri dari berbagai bangunan dengan fungsi yang berbeda-beda, termasuk pendopo, pavilion, museum, masjid, dan taman. Arsitektur Keraton menggabungkan filosofi kosmologi Jawa dengan tata letak yang sangat simbolis, mencerminkan hubungan antara manusia, alam, dan Tuhan. Setiap sudut dan ornamen di Keraton memiliki makna filosofis yang mendalam.

Wisatawan yang berkunjung ke Keraton dapat melihat berbagai koleksi pusaka keraton seperti gamelan kuno, keris, pakaian adat, foto-foto sejarah, dan berbagai benda bersejarah lainnya. Setiap hari, para abdi dalem (pelayan keraton) mengenakan pakaian adat tradisional dan melakukan tugas-tugas mereka dengan penuh khidmat, memberikan pengalaman autentik kepada pengunjung. Pertunjukan tari klasik dan gamelan juga sering diadakan di keraton sebagai bagian dari pelestarian budaya.`,
    history: `Keraton Yogyakarta didirikan oleh Sri Sultan Hamengku Buwono I pada tahun 1755, setelah terjadinya Perjanjian Giyanti yang memecah Kerajaan Mataram menjadi Kasunanan Surakarta dan Kasultanan Yogyakarta. Sultan Hamengku Buwono I memilih lokasi strategis di antara Sungai Code dan Sungai Winongo sebagai tempat pembangunan keraton baru.

Pembangunan Keraton dimulai pada tanggal 9 Oktober 1755 dan diresmikan pada 7 Oktober 1756. Perencanaan tata letak keraton dilakukan dengan sangat teliti berdasarkan konsep kosmologi Jawa dan petunjuk spiritual. Keraton dibangun menghadap ke utara menuju Gunung Merapi dan ke selatan menuju Laut Selatan (Samudra Hindia), mencerminkan kepercayaan tentang poros jagad raya dalam kosmologi Jawa.

Pada masa pemerintahan Sultan Hamengku Buwono I hingga Sultan Hamengku Buwono IX, Keraton Yogyakarta mengalami berbagai perkembangan dan renovasi. Setiap sultan memberikan kontribusi dalam memperkaya dan memperluas kompleks keraton, menambah bangunan baru, dan memperkuat struktur yang sudah ada.

Selama perang Jawa (1825-1830) yang dipimpin oleh Pangeran Diponegoro, Keraton Yogyakarta menjadi pusat perlawanan terhadap kolonialisme Belanda. Meskipun mengalami tekanan politik dan militer dari Belanda, keraton tetap bertahan dan mempertahankan kedaulatannya.

Pada masa revolusi kemerdekaan Indonesia (1945-1949), Sultan Hamengku Buwono IX memainkan peran penting dengan menyatakan Kasultanan Yogyakarta bergabung dengan Republik Indonesia. Yogyakarta menjadi ibu kota Indonesia ketika Jakarta diduduki Belanda, dan Keraton menjadi pusat pemerintahan nasional. Presiden Soekarno dan para pemimpin nasional lainnya sering menggunakan Keraton untuk rapat-rapat penting.

Setelah kemerdekaan, Keraton Yogyakarta mendapat status khusus sebagai Daerah Istimewa dengan Sultan sebagai Gubernur. Pada tahun 1950-an, Keraton mulai dibuka untuk umum sebagai tempat wisata budaya, namun tetap berfungsi sebagai istana residen Sultan yang masih memerintah hingga saat ini.

Pada era modern, di bawah kepemimpinan Sultan Hamengku Buwono X (yang menjabat sejak 1989 hingga sekarang), Keraton terus melakukan pelestarian dan revitalisasi budaya. Berbagai program pelestarian warisan budaya, pendidikan seni dan budaya Jawa, serta pengembangan pariwisata budaya dilakukan secara aktif. Keraton Yogyakarta kini menjadi salah satu destinasi wisata budaya paling penting di Indonesia, menarik ratusan ribu wisatawan setiap tahunnya yang ingin merasakan kemegahan dan kekayaan budaya Jawa.`,
  },
  {
    id: 'candi-prambanan',
    name: 'Candi Prambanan',
    category: 'wisata',
    image: 'https://images.unsplash.com/photo-1578469550956-0e16b69c6a3d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmFtYmFuYW4lMjB0ZW1wbGV8ZW58MXx8fHwxNzY1MjYzNDA4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Candi Prambanan atau Candi Rara Jonggrang adalah kompleks candi Hindu terbesar di Indonesia dan salah satu candi terindah di Asia Tenggara. Terletak sekitar 17 kilometer timur laut Yogyakarta, candi ini merupakan Situs Warisan Dunia UNESCO sejak tahun 1991. Kompleks candi ini terdiri dari 240 candi dengan tiga candi utama yang didedikasikan untuk Trimurti: Brahma, Wisnu, dan Siwa.

Candi utama Siwa memiliki tinggi 47 meter dan menjadi bangunan tertinggi dalam kompleks ini. Arsitektur Candi Prambanan menampilkan keindahan relief yang sangat detail, menggambarkan kisah Ramayana dan berbagai adegan dari kitab suci Hindu lainnya. Setiap panel relief diukir dengan sangat halus dan artistik, menunjukkan tingkat keahlian seniman Jawa kuno yang luar biasa tinggi.

Setiap malam, di panggung terbuka di kompleks Candi Prambanan, dipentaskan pertunjukan Sendratari Ramayana yang spektakuler. Pertunjukan ini menampilkan ratusan penari dan penabuh gamelan yang mementaskan kisah epik Ramayana dengan latar belakang Candi Prambanan yang megah dan pencahayaan dramatis. Sendratari Ramayana Prambanan telah menjadi salah satu atraksi wisata budaya paling terkenal di Indonesia dan menarik ribuan wisatawan mancanegara setiap tahunnya.`,
    history: `Candi Prambanan dibangun pada abad ke-9 Masehi, sekitar tahun 850 M, pada masa pemerintahan Rakai Pikatan dari Dinasti Sanjaya dan Rakai Balitung dari Kerajaan Mataram Kuno. Pembangunan candi ini dimulai sebagai bentuk tandingan terhadap Candi Borobudur yang merupakan candi Buddha, sekaligus sebagai tanda kebangkitan kembali agama Hindu di Jawa Tengah setelah periode dominasi Buddha.

Menurut prasasti Siwagrha yang ditemukan di sekitar kompleks candi, pembangunan candi utama yang didedikasikan untuk Dewa Siwa selesai pada sekitar tahun 856 M. Pembangunan ini melibatkan ribuan pekerja dan memakan waktu puluhan tahun untuk menyelesaikan seluruh kompleks.

Pada abad ke-10, terjadi perpindahan pusat kekuasaan Kerajaan Mataram dari Jawa Tengah ke Jawa Timur. Penyebab perpindahan ini masih menjadi misteri, namun diduga terkait dengan bencana alam seperti letusan gunung berapi. Setelah ditinggalkan, Candi Prambanan mulai mengalami kerusakan akibat gempa bumi, letusan gunung berapi, dan penjarahan.

Pada abad ke-16, ketika Islam mulai berkembang di Jawa, legenda Rara Jonggrang mulai berkembang di masyarakat. Legenda ini menceritakan tentang seorang putri cantik yang dikutuk menjadi arca di dalam candi karena menolak pinangan seorang pangeran dengan tipu muslihat.

Candi Prambanan ditemukan kembali oleh dunia pada tahun 1733 oleh CA Lons, seorang penjelajah Belanda. Namun, kondisi candi saat itu sudah sangat rusak dan sebagian besar bangunan runtuh. Pada tahun 1885, Jan Willem IJzerman mulai melakukan pembersihan dan pendataan reruntuhan candi.

Pemugaran besar-besaran dimulai pada tahun 1918 di bawah koordinasi Dienst van Oudheidkundig Onderzoek (Dinas Purbakala Hindia Belanda). Pemugaran Candi Siwa utama selesai pada tahun 1953, diikuti dengan pemugaran candi-candi lainnya yang berlangsung hingga tahun 1990-an.

Pada tahun 1991, UNESCO menetapkan Candi Prambanan sebagai Situs Warisan Dunia atas dasar kriteria budaya yang luar biasa. Gempa bumi besar pada tahun 2006 kembali merusak sebagian struktur candi, namun segera dilakukan pemugaran dan perbaikan.

Pertunjukan Sendratari Ramayana di Candi Prambanan pertama kali dipentaskan pada tahun 1961 dan sejak itu menjadi tradisi tahunan yang terus berlangsung. Pertunjukan ini mengalami perkembangan dari segi koreografi, tata panggung, dan produksi, menjadikannya salah satu pertunjukan seni tari paling spektakuler di Indonesia. Saat ini, Candi Prambanan tidak hanya menjadi situs arkeologi penting, tetapi juga pusat kegiatan budaya dan pariwisata yang vital bagi Yogyakarta dan Indonesia.`,
  },
  {
    id: 'malioboro',
    name: 'Malioboro',
    category: 'wisata',
    image: 'https://images.unsplash.com/photo-1707378174175-82ebe2ee16fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxpb2Jvcm8lMjBzdHJlZXQlMjB5b2d5YWthcnRhfGVufDF8fHx8MTc2NTI2MzQwOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Jalan Malioboro adalah ikon wisata belanja dan budaya Yogyakarta yang paling terkenal. Membentang sepanjang 2,5 kilometer dari Tugu Yogyakarta di utara hingga Keraton Yogyakarta di selatan, Malioboro menjadi pusat aktivitas ekonomi, budaya, dan pariwisata kota. Jalan ini selalu ramai dikunjungi wisatawan dari pagi hingga malam hari, dengan berbagai aktivitas dan atraksi yang menarik.

Di sepanjang jalan Malioboro, terdapat ratusan toko, pedagang kaki lima, dan pusat perbelanjaan yang menjual berbagai produk khas Yogyakarta seperti batik, kerajinan tangan, aksesori, pakaian, dan oleh-oleh. Pedagang lesehan yang duduk di trotoar menjadi ciri khas Malioboro, menawarkan harga yang bisa ditawar dan suasana belanja yang khas dan menyenangkan.

Malioboro juga terkenal dengan kuliner jalanannya yang beragam. Di malam hari, Malioboro berubah menjadi surga kuliner dengan berbagai angkringan, warung lesehan, dan pedagang makanan yang menjual gudeg, bakpia, wedang ronde, dan berbagai makanan tradisional lainnya. Andong (kereta kuda) dan becak juga menjadi moda transportasi tradisional yang bisa digunakan wisatawan untuk menelusuri Malioboro dengan cara yang unik dan berkesan.`,
    history: `Nama Malioboro dipercaya berasal dari nama Duke of Marlborough (Malbro), seorang jenderal Inggris yang pernah berkuasa di Jawa pada awal abad ke-19 ketika Inggris mengambil alih kendali dari Belanda untuk sementara waktu (1811-1816). Namun, ada juga yang berpendapat bahwa nama ini berasal dari bahasa Sanskerta "Malya Bhara" yang berarti "karangan bunga".

Jalan Malioboro dibangun pada masa Sultan Hamengku Buwono I (1755-1792) sebagai jalan protokol yang menghubungkan Keraton dengan Tugu Golong-Gilig (sekarang Tugu Yogyakarta). Jalan ini dirancang sebagai bagian dari filosofi "Manunggaling Kawula Gusti" dengan konsep sumbu imajiner yang menghubungkan Keraton, Tugu, dan Gunung Merapi di utara serta Pantai Parangtritis di selatan.

Pada masa kolonial Belanda abad ke-19, Malioboro mulai berkembang sebagai kawasan perdagangan. Banyak pedagang Belanda, Tionghoa, Arab, dan India yang membuka toko-toko di sepanjang jalan ini. Bangunan-bangunan dengan gaya arsitektur Eropa dan Indies mulai bermunculan, beberapa di antaranya masih berdiri hingga sekarang.

Pada masa pendudukan Jepang (1942-1945), aktivitas perdagangan di Malioboro sempat menurun akibat kondisi ekonomi yang sulit. Namun, setelah kemerdekaan Indonesia, Malioboro kembali bangkit dan menjadi pusat perdagangan yang lebih ramai.

Pada tahun 1950-an hingga 1970-an, Malioboro mengalami perkembangan pesat dengan munculnya berbagai toko modern, hotel, dan bioskop. Pada era ini juga mulai berkembang pedagang kaki lima yang menjual batik dan kerajinan tangan kepada wisatawan. Pedagang lesehan yang duduk di trotoar menjadi fenomena unik yang menjadi ciri khas Malioboro.

Pada tahun 1980-an, Pemerintah Kota Yogyakarta mulai melakukan penataan dan regulasi terhadap pedagang kaki lima di Malioboro untuk menciptakan keteraturan. Namun, tetap dijaga karakteristik dan keunikan Malioboro sebagai kawasan perdagangan tradisional yang ramah wisatawan.

Di era 1990-an hingga 2000-an, Malioboro semakin berkembang dengan munculnya berbagai mal modern seperti Malioboro Mall dan Galeria Mall. Namun, keberadaan pedagang kaki lima dan suasana tradisional tetap dipertahankan sebagai daya tarik utama.

Pada tahun 2019, Pemerintah Kota Yogyakarta melakukan revitalisasi besar-besaran terhadap kawasan Malioboro dengan menata trotoar, pedestrian, jalur sepeda, dan ruang terbuka hijau. Proyek ini bertujuan untuk membuat Malioboro lebih nyaman bagi pejalan kaki dan lebih ramah lingkungan, sambil tetap mempertahankan identitas budaya dan karakteristik uniknya.

Hingga kini, Malioboro tetap menjadi jantung pariwisata Yogyakarta dan simbol kota yang tidak pernah tidur. Setiap tahun, jutaan wisatawan domestik dan mancanegara mengunjungi Malioboro untuk berbelanja, mencicipi kuliner khas, menikmati seni jalanan, dan merasakan atmosfer budaya Jawa yang autentik. Malioboro telah menjadi lebih dari sekadar jalan atau kawasan perdagangan, tetapi sebuah pengalaman budaya yang lengkap dan tak terlupakan.`,
  },
  {
    id: 'museum-sonobudoyo',
    name: 'Museum Sonobudoyo',
    category: 'wisata',
    image: 'https://images.unsplash.com/photo-1680144653445-9ea91934e5d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvbmVzaWFuJTIwbXVzZXVtJTIwaGVyaXRhZ2V8ZW58MXx8fHwxNzY1MjYzNDEzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Museum Sonobudoyo adalah museum budaya dan sejarah yang terletak di sebelah utara Alun-alun Utara Yogyakarta, tepat di depan Keraton Yogyakarta. Museum ini menyimpan koleksi seni dan budaya Jawa yang sangat lengkap, menjadikannya salah satu museum terbaik di Indonesia untuk mempelajari kebudayaan Jawa. Koleksi museum mencakup lebih dari 43.000 benda bersejarah, termasuk wayang kulit, wayang golek, topeng, keris, gamelan, arca, prasasti, tekstil, dan berbagai benda seni lainnya.

Museum Sonobudoyo memiliki arsitektur yang unik dengan gaya Jawa tradisional, dengan pendopo dan bangunan-bangunan yang mencerminkan filosofi arsitektur Jawa klasik. Tata letak museum dirancang dengan mempertimbangkan konsep kosmologi Jawa, menciptakan suasana yang sakral dan penuh makna spiritual.

Salah satu daya tarik utama Museum Sonobudoyo adalah koleksi wayang kulitnya yang sangat lengkap, mencakup berbagai jenis wayang dari berbagai periode dan daerah di Jawa. Museum juga rutin mengadakan pertunjukan wayang kulit setiap malam untuk memberikan pengalaman budaya yang autentik kepada pengunjung. Selain itu, terdapat perpustakaan yang menyimpan naskah-naskah kuno dan buku-buku langka tentang budaya Jawa.`,
    history: `Museum Sonobudoyo didirikan pada tanggal 6 November 1935 oleh Yayasan Jawa (Java Instituut), sebuah lembaga yang didirikan oleh pemerintah Hindia Belanda dan para bangsawan Jawa untuk mempelajari dan melestarikan budaya Jawa. Nama "Sonobudoyo" berasal dari bahasa Jawa kuno yang berarti "yang berbudi luhur" atau "tempat berkumpulnya orang-orang berbudi luhur".

Pendirian museum ini diprakarsai oleh Dr. K.P.H. Soerjaningrat (Ki Hadjar Dewantara) dan beberapa tokoh budaya lainnya yang prihatin terhadap kelestarian budaya Jawa di tengah modernisasi dan pengaruh budaya Barat. Museum ini awalnya didirikan dengan tujuan untuk mengumpulkan, melestarikan, dan meneliti benda-benda budaya Jawa agar tidak punah atau dijarah oleh pihak-pihak yang tidak bertanggung jawab.

Pada masa pendudukan Jepang (1942-1945), museum sempat ditutup dan koleksinya disembunyikan untuk menghindari penjarahan. Setelah kemerdekaan Indonesia, museum dibuka kembali dan dikelola oleh pemerintah Indonesia. Pada tahun 1950-an, museum mengalami renovasi dan perluasan dengan penambahan gedung-gedung baru untuk menampung koleksi yang semakin bertambah.

Pada era Orde Baru (1966-1998), Museum Sonobudoyo mendapat perhatian khusus dari pemerintah pusat dan daerah sebagai bagian dari upaya pelestarian budaya nasional. Berbagai ekspedisi dan penelitian dilakukan untuk mengumpulkan benda-benda budaya dari berbagai daerah di Jawa, memperkaya koleksi museum.

Pada tahun 1984, Museum Sonobudoyo secara resmi diserahkan kepada Pemerintah Provinsi Daerah Istimewa Yogyakarta dan menjadi Unit Pelaksana Teknis (UPT) di bawah Dinas Kebudayaan. Sejak saat itu, museum mengalami berbagai pembenahan dalam hal manajemen, konservasi koleksi, dan pelayanan kepada pengunjung.

Pada tahun 2006, Museum Sonobudoyo mengalami kerusakan akibat gempa bumi besar yang melanda Yogyakarta. Bangunan museum retak dan beberapa koleksi rusak. Segera dilakukan perbaikan dan renovasi dengan dukungan dari berbagai pihak, termasuk UNESCO dan pemerintah Jepang.

Di era modern, Museum Sonobudoyo terus melakukan inovasi dengan menghadirkan teknologi digital dalam pamerannya. Pada tahun 2017, dibuka Museum Sonobudoyo Unit II di kawasan Ndalem Condrokiranan untuk menampung koleksi yang semakin banyak dan memberikan ruang pamer yang lebih luas.

Saat ini, Museum Sonobudoyo menjadi salah satu destinasi wisata edukasi yang penting di Yogyakarta. Setiap tahun, ribuan pelajar, mahasiswa, peneliti, dan wisatawan mengunjungi museum untuk belajar tentang budaya Jawa. Museum juga aktif mengadakan berbagai kegiatan budaya seperti workshop kerajinan, pertunjukan seni, seminar, dan pameran temporer untuk menjaga relevansi dan daya tarik museum di era digital.`,
  },
  {
    id: 'sentra-batik',
    name: 'Sentra Batik',
    category: 'wisata',
    image: 'https://images.unsplash.com/photo-1604973104381-870c92f10343?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXRpayUyMGluZG9uZXNpYXxlbnwxfHx8fDE3NjUyNjM0MDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Sentra Batik di Yogyakarta merupakan kawasan-kawasan yang menjadi pusat produksi dan penjualan batik tradisional dan modern. Beberapa sentra batik terkenal di Yogyakarta antara lain Kampung Batik Giriloyo, Kampung Batik Wijilan, Sentra Batik Tirtodipuran, dan Sentra Batik Imogiri. Setiap sentra memiliki karakteristik dan keunikan tersendiri dalam motif, teknik, dan produk yang dihasilkan.

Di sentra batik, wisatawan tidak hanya bisa membeli batik dengan harga yang lebih terjangkau langsung dari pengrajin, tetapi juga dapat mempelajari proses pembuatan batik dari awal hingga akhir. Banyak sentra batik yang menyediakan workshop dan kursus membatik untuk wisatawan yang ingin merasakan pengalaman membuat batik sendiri. Pengalaman hands-on ini memberikan apresiasi yang lebih dalam terhadap seni batik dan kerja keras yang dibutuhkan untuk menciptakan selembar kain batik berkualitas.

Sentra batik juga menjadi tempat pelestarian berbagai motif batik tradisional yang sudah berusia ratusan tahun, serta tempat inovasi motif-motif batik kontemporer yang disesuaikan dengan selera pasar modern. Para pengrajin batik di sentra-sentra ini mempertahankan teknik tradisional seperti batik tulis dan batik cap, sambil juga mengeksplorasi desain-desain baru yang menarik minat generasi muda.`,
    history: `Sejarah sentra batik di Yogyakarta tidak dapat dipisahkan dari sejarah batik itu sendiri yang telah berkembang sejak era Kerajaan Mataram. Pada awalnya, batik merupakan kerajinan eksklusif yang hanya dilakukan di lingkungan keraton dan rumah-rumah bangsawan. Para putri dan permaisuri keraton mengajarkan keterampilan membatik kepada para abdi dalem perempuan.

Pada abad ke-19, ketika batik mulai berkembang menjadi komoditas komersial, beberapa kawasan di sekitar Keraton Yogyakarta mulai menjadi sentra produksi batik. Kampung Wijilan, yang terletak tidak jauh dari keraton, menjadi salah satu sentra batik tertua di Yogyakarta. Para pengrajin di Wijilan banyak yang merupakan keturunan abdi dalem keraton yang telah mempelajari seni batik dari para bangsawan.

Pada awal abad ke-20, sentra batik berkembang ke wilayah Tirtodipuran dan Prawirotaman, yang hingga kini masih menjadi kawasan penghasil batik berkualitas tinggi. Kawasan ini banyak dikunjungi oleh pedagang dari berbagai daerah untuk membeli batik dalam jumlah besar.

Pada masa kolonial Belanda, industri batik Yogyakarta mengalami perkembangan pesat dengan masuknya teknologi batik cap yang mempercepat proses produksi. Namun, batik tulis tetap dipertahankan sebagai produk premium dengan nilai seni yang lebih tinggi.

Setelah kemerdekaan Indonesia, terutama pada era 1950-an hingga 1970-an, sentra batik Yogyakarta mengalami masa kejayaan dengan banyaknya permintaan dari dalam dan luar negeri. Pemerintah memberikan dukungan melalui berbagai program pelatihan dan bantuan modal untuk pengrajin batik.

Pada tahun 1980-an hingga 1990-an, industri batik mengalami penurunan karena kompetisi dengan tekstil printing modern yang lebih murah. Banyak pengrajin yang beralih profesi atau mengurangi skala produksi. Namun, beberapa sentra batik seperti Giriloyo yang terletak di lereng Imogiri tetap bertahan dengan mempertahankan kualitas dan tradisi batik tulis.

Pengakuan UNESCO terhadap batik Indonesia sebagai Warisan Budaya Tak Benda Manusia pada tahun 2009 memberikan dampak positif yang luar biasa bagi sentra batik di Yogyakarta. Minat masyarakat terhadap batik meningkat drastis, dan pemerintah daerah mulai gencar mempromosikan sentra batik sebagai destinasi wisata edukasi.

Pada tahun 2010-an, konsep wisata batik berkembang dengan munculnya berbagai paket wisata yang menggabungkan kunjungan ke sentra batik dengan pengalaman membatik. Kampung Batik Giriloyo menjadi pionir dalam mengembangkan konsep desa wisata batik yang komprehensif, di mana wisatawan dapat menginap, belajar membatik, dan membeli produk langsung dari pengrajin.

Saat ini, sentra batik di Yogyakarta tidak hanya berfungsi sebagai tempat produksi, tetapi juga sebagai pusat edukasi, konservasi motif tradisional, dan inovasi desain batik kontemporer. Berbagai program pemberdayaan pengrajin batik terus dilakukan oleh pemerintah dan lembaga swadaya masyarakat untuk memastikan keberlanjutan industri batik dan peningkatan kesejahteraan pengrajin. Sentra batik Yogyakarta kini menjadi model pengembangan industri kreatif berbasis budaya lokal yang berhasil dan berkelanjutan.`,
  },

  // ENERGI ALTERNATIF
  {
    id: 'energi-surya',
    name: 'Energi Surya',
    category: 'energi',
    image: 'https://images.unsplash.com/photo-1628206554160-63e8c921e398?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2xhciUyMHBhbmVscyUyMHJlbmV3YWJsZSUyMGVuZXJneXxlbnwxfHx8fDE3NjUxODIzMTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Energi Surya adalah salah satu sumber energi alternatif yang paling potensial dan aktif dikembangkan di Daerah Istimewa Yogyakarta. Dengan rata-rata radiasi matahari yang cukup tinggi sepanjang tahun, Yogyakarta memiliki kondisi geografis yang sangat mendukung untuk pengembangan teknologi solar photovoltaic (PV). Pemerintah daerah bersama dengan berbagai institusi pendidikan dan sektor swasta telah melakukan berbagai inisiatif untuk mengembangkan dan mengaplikasikan energi surya dalam berbagai aspek kehidupan masyarakat.

Penerapan energi surya di Yogyakarta mencakup berbagai sektor, mulai dari penerangan jalan umum (PJU), elektrifikasi rumah tangga di daerah terpencil, hingga pembangkit listrik tenaga surya skala besar untuk kegiatan industri dan komersial. Solar photovoltaic juga dimanfaatkan untuk mendukung kegiatan ekonomi produktif seperti pompa air untuk irigasi pertanian dan budidaya ikan, mesin pendingin untuk penyimpanan hasil panen, dan berbagai peralatan lain yang mendukung peningkatan produktivitas masyarakat.

Kampus-kampus besar di Yogyakarta seperti Universitas Gadjah Mada (UGM), Universitas Negeri Yogyakarta (UNY), Universitas Muhammadiyah Yogyakarta (UMY), dan Universitas Kristen Duta Wacana (UKDW) telah memasang sistem solar panel di gedung-gedung kampus untuk mengurangi konsumsi listrik dari PLN dan mengurangi emisi karbon. Instalasi ini tidak hanya berfungsi sebagai sumber energi, tetapi juga sebagai sarana edukasi dan penelitian bagi mahasiswa dan dosen.`,
    history: `Pengembangan energi surya di Yogyakarta dimulai pada awal tahun 2000-an ketika pemerintah pusat Indonesia mulai menggalakkan program energi terbarukan untuk mengurangi ketergantungan pada bahan bakar fosil. Pada tahun 2005, Pemerintah Provinsi DIY meluncurkan program percontohan Pembangkit Listrik Tenaga Surya (PLTS) di beberapa desa terpencil di Gunungkidul yang belum teraliri listrik PLN.

Kabupaten Gunungkidul, yang memiliki karakteristik geografis berupa dataran tinggi karst dengan akses listrik terbatas, menjadi lokasi prioritas untuk pengembangan energi surya. Pada tahun 2007-2010, dengan dukungan dari berbagai lembaga donor internasional dan pemerintah pusat, ratusan rumah tangga di Gunungkidul mendapat bantuan instalasi Solar Home System (SHS) yang memungkinkan mereka memiliki akses terhadap listrik untuk penerangan dan kebutuhan dasar lainnya.

Pada tahun 2011, UGM menjadi pelopor di kalangan universitas dengan memasang sistem PLTS berkapasitas 12 kWp di atap gedung fakultas teknik. Instalasi ini menjadi model dan inspirasi bagi kampus-kampus lain untuk mengadopsi energi surya. Pada tahun-tahun berikutnya, UNY, UMY, dan UKDW juga memasang sistem solar panel dengan kapasitas yang lebih besar.

Pada tahun 2014, Pemerintah DIY meluncurkan program "Yogyakarta Menuju Provinsi Ramah Lingkungan" yang salah satu fokusnya adalah peningkatan penggunaan energi terbarukan, khususnya energi surya. Program ini mencakup penyediaan insentif dan kemudahan perizinan bagi masyarakat dan pelaku usaha yang ingin memasang sistem solar panel.

Pada tahun 2016-2017, program Penerangan Jalan Umum Tenaga Surya (PJU-TS) mulai diimplementasikan di berbagai kawasan di Yogyakarta, termasuk di jalan-jalan desa, kawasan wisata, dan area publik. PJU-TS tidak hanya memberikan penerangan yang lebih baik dan hemat energi, tetapi juga meningkatkan keamanan dan aktivitas ekonomi malam hari di kawasan-kawasan tersebut.

Pada tahun 2018, sebuah proyek percontohan di Gunungkidul menggunakan solar photovoltaic untuk mendukung budidaya ikan lele dalam kolam terpal. Sistem pompa air bertenaga surya memungkinkan sirkulasi air yang optimal, sementara sistem aerasi solar-powered meningkatkan kandungan oksigen dalam kolam, meningkatkan produktivitas budidaya secara signifikan.

Di era 2019-2021, pandemi COVID-19 justru mendorong percepatan adopsi energi surya di Yogyakarta. Banyak pelaku usaha mikro dan rumah tangga yang mulai berinvestasi pada solar panel untuk mengurangi biaya operasional di tengah ketidakpastian ekonomi. Pemerintah juga memberikan bantuan dan subsidi untuk instalasi PLTS bagi UMKM yang terdampak pandemi.

Pada tahun 2022, Pemerintah DIY meluncurkan roadmap energi terbarukan yang menargetkan 20% kebutuhan energi provinsi dipenuhi dari sumber terbarukan pada tahun 2030, dengan energi surya sebagai kontributor utama. Berbagai kebijakan pendukung seperti net metering, feed-in tariff, dan kemudahan pembiayaan melalui perbankan terus dikembangkan.

Saat ini, Yogyakarta memiliki total kapasitas terpasang PLTS sekitar 15 MW yang tersebar di rumah tangga, gedung pemerintah, kampus, industri, dan fasilitas publik. Energi surya telah berkontribusi signifikan dalam mengurangi emisi karbon Yogyakarta sekitar 8.000 ton CO2 per tahun. Program-program edukasi dan sosialisasi terus dilakukan untuk meningkatkan kesadaran masyarakat tentang manfaat energi surya dan mendorong adopsi yang lebih luas di masa depan.`,
  },
  {
    id: 'energi-biomassa',
    name: 'Energi Biomassa',
    category: 'energi',
    image: 'https://images.unsplash.com/photo-1507715524600-6fb8e965fe2f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaW9tYXNzJTIwZW5lcmd5fGVufDF8fHx8MTc2NTI2MzQxMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Energi Biomassa adalah energi yang dihasilkan dari bahan-bahan organik seperti limbah pertanian, limbah ternak, sampah organik, dan tanaman energi. Di Yogyakarta, pengembangan energi biomassa sangat relevan mengingat karakteristik wilayah yang sebagian besar merupakan daerah pertanian dan peternakan. Biomassa menjadi solusi untuk mengolah limbah organik yang selama ini menjadi masalah lingkungan menjadi sumber energi yang bermanfaat.

Teknologi yang dikembangkan dalam pemanfaatan energi biomassa di Yogyakarta meliputi biogas, gasifikasi biomassa, dan pembakaran langsung biomassa untuk menghasilkan panas atau listrik. Biogas yang dihasilkan dari limbah ternak sapi, kambing, dan ayam digunakan untuk memasak dan penerangan rumah tangga, menggantikan LPG dan minyak tanah. Teknologi gasifikasi biomassa digunakan untuk mengkonversi sekam padi, tongkol jagung, dan limbah kayu menjadi gas yang dapat digunakan untuk menggerakkan generator listrik.

Selain memberikan manfaat energi, pemanfaatan biomassa juga memberikan manfaat lingkungan yang signifikan dengan mengurangi emisi gas rumah kaca dari pembusukan limbah organik. Limbah dari proses produksi biogas juga dapat dimanfaatkan sebagai pupuk organik berkualitas tinggi yang meningkatkan produktivitas pertanian. Dengan demikian, energi biomassa menciptakan sistem siklus yang berkelanjutan dan ramah lingkungan.`,
    history: `Sejarah pengembangan energi biomassa di Yogyakarta dimulai pada tahun 1980-an ketika pemerintah Indonesia meluncurkan program biogas nasional untuk mengatasi krisis energi. Pada masa itu, beberapa peternakan sapi perah di Sleman mulai mengadopsi teknologi biogas sederhana untuk mengolah kotoran sapi menjadi gas memasak.

Pada tahun 1990-an, program biogas mengalami penurunan karena kurangnya dukungan teknis dan ekonomi. Banyak instalasi biogas yang rusak dan tidak terurus sehingga program ini hampir terhenti sepenuhnya. Namun, beberapa kelompok tani di Yogyakarta tetap mempertahankan dan mengembangkan teknologi biogas secara mandiri.

Pada tahun 2009, program biogas mendapat momentum baru dengan diluncurkannya program "Biogas Rumah" (BIRU) oleh Kementerian ESDM bekerja sama dengan Hivos, sebuah organisasi internasional dari Belanda. Program ini memberikan subsidi dan pendampingan teknis kepada peternak yang ingin membangun instalasi biogas. Di Yogyakarta, ribuan peternak di Sleman, Bantul, dan Gunungkidul mendapat bantuan pembangunan reaktor biogas dengan kapasitas 4-8 m3.

Pada tahun 2012-2014, UGM melalui Pusat Studi Energi mengembangkan teknologi gasifikasi biomassa untuk mengkonversi limbah pertanian menjadi listrik. Sebuah pilot project di desa Poncosari, Srandakan, Bantul, berhasil membangun pembangkit listrik tenaga gasifikasi biomassa (PLTBm) dengan kapasitas 40 kW yang memanfaatkan sekam padi dan tongkol jagung. Proyek ini menjadi model pengembangan PLTBm skala komunitas di Indonesia.

Pada tahun 2015, Pemerintah DIY meluncurkan program "Kampung Biogas" yang bertujuan untuk mengembangkan desa-desa mandiri energi berbasis biogas. Beberapa desa di Sleman seperti Wukirsari dan Trimulyo dijadikan desa percontohan di mana hampir setiap rumah tangga peternak memiliki instalasi biogas. Program ini tidak hanya menyediakan energi untuk memasak, tetapi juga meningkatkan kesehatan lingkungan dengan mengurangi pencemaran dari limbah ternak.

Pada tahun 2017, UMY mengembangkan teknologi biogas skala kecil yang lebih efisien dan terjangkau untuk peternak kecil. Desain reaktor yang disederhanakan dan menggunakan material lokal membuat biaya investasi lebih rendah, sehingga lebih banyak peternak yang mampu mengadopsi teknologi ini.

Pada tahun 2019-2020, beberapa pasar tradisional di Yogyakarta mulai mengembangkan sistem pengolahan sampah organik menjadi biogas. Pasar Beringharjo dan Pasar Kranggan memasang reaktor biogas untuk mengolah sampah sayur dan buah menjadi gas yang digunakan untuk penerangan pasar. Limbah dari proses biogas digunakan sebagai pupuk organik yang dijual kepada petani.

Di era pandemi COVID-19 (2020-2021), program energi biomassa mendapat perhatian lebih besar karena dianggap dapat meningkatkan ketahanan energi dan ekonomi rumah tangga di pedesaan. Banyak peternak yang merasakan manfaat signifikan dari biogas dalam mengurangi biaya operasional peternakan.

Pada tahun 2023, Pemerintah DIY meluncurkan program "Desa Energi Biomassa Berkelanjutan" yang mengintegrasikan berbagai teknologi biomassa dengan pertanian dan peternakan. Program ini mencakup pembangunan PLTBm skala komunitas, instalasi biogas komunal, dan pengembangan briket biomassa sebagai bahan bakar alternatif.

Saat ini, Yogyakarta memiliki lebih dari 5.000 instalasi biogas aktif dan beberapa PLTBm skala komunitas dengan total kapasitas sekitar 500 kW. Energi biomassa telah mengurangi konsumsi LPG sekitar 2 juta kilogram per tahun dan mengurangi emisi karbon sekitar 15.000 ton CO2 per tahun. Pengembangan energi biomassa terus didorong sebagai bagian dari strategi ekonomi sirkular dan pembangunan berkelanjutan di Yogyakarta.`,
  },
  {
    id: 'energi-angin',
    name: 'Energi Angin',
    category: 'energi',
    image: 'https://images.unsplash.com/photo-1599405032290-29d6e9e7274c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aW5kJTIwdHVyYmluZSUyMGVuZXJneXxlbnwxfHx8fDE3NjUxODU1MTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Energi Angin adalah sumber energi terbarukan yang dihasilkan dari konversi energi kinetik angin menjadi energi listrik menggunakan turbin angin. Meskipun Yogyakarta bukan daerah dengan kecepatan angin setinggi daerah pesisir atau dataran tinggi lainnya di Indonesia, namun di beberapa wilayah seperti kawasan pantai selatan (Parangtritis, Samas, Glagah) dan dataran tinggi Gunungkidul, terdapat potensi energi angin yang cukup untuk dikembangkan, terutama untuk aplikasi skala kecil dan menengah.

Pengembangan energi angin di Yogyakarta lebih fokus pada turbin angin skala kecil (small wind turbine) dengan kapasitas 1-10 kW yang cocok untuk aplikasi off-grid di lokasi terpencil, penerangan kawasan wisata pantai, pompa air untuk irigasi, dan hybrid system yang dikombinasikan dengan solar photovoltaic untuk meningkatkan keandalan suplai energi. Beberapa kampus dan lembaga penelitian di Yogyakarta aktif melakukan riset dan pengembangan desain turbin angin yang sesuai dengan kondisi angin di Indonesia.

Potensi energi angin juga dieksplorasi untuk mendukung sektor pariwisata, khususnya di kawasan pantai yang menjadi destinasi wisata populer. Instalasi turbin angin tidak hanya berfungsi sebagai pembangkit listrik, tetapi juga sebagai atraksi edukasi tentang energi terbarukan yang menarik bagi wisatawan, terutama generasi muda yang semakin peduli terhadap isu lingkungan dan perubahan iklim.`,
    history: `Pengembangan energi angin di Yogyakarta dimulai pada awal tahun 2000-an ketika UGM mulai melakukan studi potensi energi angin di berbagai wilayah Yogyakarta. Penelitian awal menunjukkan bahwa kawasan pantai selatan dan beberapa titik di dataran tinggi Gunungkidul memiliki kecepatan angin rata-rata 3-5 m/s yang cukup untuk aplikasi turbin angin skala kecil.

Pada tahun 2006, Jurusan Teknik Elektro UGM melakukan instalasi turbin angin eksperimental dengan kapasitas 1 kW di kampus sebagai bagian dari proyek penelitian mahasiswa. Meskipun masih bersifat eksperimental, proyek ini memberikan pembelajaran berharga tentang karakteristik angin lokal dan desain turbin yang sesuai.

Pada tahun 2008-2010, beberapa proyek percontohan turbin angin skala kecil dipasang di kawasan pantai Parangtritis dan Glagah untuk penerangan area parkir dan toilet umum. Sistem hybrid solar-wind dipilih untuk meningkatkan keandalan karena kecepatan angin yang berfluktuasi. Proyek ini mendapat apresiasi baik dari pengunjung dan pengelola wisata.

Pada tahun 2012, UNY melalui Fakultas Teknik mengembangkan prototipe turbin angin vertikal (Vertical Axis Wind Turbine / VAWT) yang lebih cocok untuk kondisi angin yang berubah-ubah arah. Desain ini lebih efisien untuk aplikasi di perkotaan dan kawasan dengan kecepatan angin rendah hingga menengah. Beberapa unit prototipe dipasang di atap gedung kampus untuk pengujian dan demonstrasi.

Pada tahun 2014-2015, program kemitraan antara UGM dan Pemerintah Kabupaten Gunungkidul menghasilkan instalasi sistem pompa air bertenaga hybrid solar-wind di beberapa desa di Gunungkidul yang mengalami kesulitan air. Sistem ini terbukti efektif dalam memenuhi kebutuhan air untuk irigasi dan konsumsi rumah tangga.

Pada tahun 2016, sebuah startup teknologi di Yogyakarta mengembangkan turbin angin mikro dengan kapasitas 100-500 watt yang ditujukan untuk aplikasi rumah tangga dan UMKM. Produk ini dipasarkan sebagai solusi energi backup yang ramah lingkungan dan hemat biaya operasional dalam jangka panjang.

Pada tahun 2018, Pemerintah DIY melakukan kajian potensi energi angin secara komprehensif dengan memasang beberapa stasiun pengukuran angin di berbagai lokasi strategis. Data yang dikumpulkan selama 2 tahun digunakan untuk menyusun peta potensi energi angin Yogyakarta yang menjadi acuan untuk pengembangan di masa depan.

Pada tahun 2020, UKDW melakukan instalasi turbin angin berkapasitas 5 kW yang dikombinasikan dengan sistem solar panel 20 kWp untuk mensuplai sebagian kebutuhan energi gedung kampus. Sistem hybrid ini menjadi model integrasi energi terbarukan yang dapat diadopsi oleh institusi lain.

Meskipun pengembangan energi angin di Yogyakarta tidak secepat energi surya atau biomassa, namun teknologi ini tetap mendapat perhatian sebagai bagian dari diversifikasi energi terbarukan. Riset dan pengembangan terus dilakukan untuk menemukan desain turbin yang paling efisien dan ekonomis untuk kondisi angin di Yogyakarta.

Saat ini, terdapat sekitar 50 unit turbin angin skala kecil yang tersebar di berbagai lokasi di Yogyakarta dengan total kapasitas sekitar 100 kW. Meskipun kontribusinya masih kecil, energi angin memiliki potensi untuk dikembangkan lebih lanjut, terutama dalam sistem hybrid dengan energi surya, untuk meningkatkan ketahanan energi dan mengurangi emisi karbon di Yogyakarta.`,
  },
  {
    id: 'energi-air',
    name: 'Energi Air (Mikrohidro)',
    category: 'energi',
    image: 'https://images.unsplash.com/photo-1657913014002-3d0e31a10e37?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoeWRyb3Bvd2VyJTIwd2F0ZXIlMjBlbmVyZ3l8ZW58MXx8fHwxNzY1MjYzNDEyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: `Energi Air atau Mikrohidro adalah pembangkit listrik tenaga air skala kecil yang memanfaatkan aliran sungai atau saluran irigasi untuk menghasilkan listrik dengan kapasitas di bawah 100 kW. Di Yogyakarta, teknologi mikrohidro sangat relevan mengingat banyaknya sungai-sungai kecil dan saluran irigasi yang mengalir sepanjang tahun, terutama di wilayah lereng Gunung Merapi dan dataran tinggi lainnya. Mikrohidro menjadi solusi energi yang berkelanjutan untuk desa-desa terpencil yang belum terjangkau jaringan listrik PLN.

Sistem Pembangkit Listrik Tenaga Mikrohidro (PLTMH) terdiri dari intake (pengambilan air), saluran pembawa, bak penenang, pipa pesat (penstock), turbin, generator, dan sistem kontrol. Teknologi ini memiliki keunggulan berupa sumber energi yang kontinyu (24 jam), ramah lingkungan karena tidak menghasilkan emisi, biaya operasional yang sangat rendah, dan umur teknis yang panjang bisa mencapai 30-50 tahun.

Selain untuk penerangan rumah tangga dan kebutuhan listrik dasar, energi dari PLTMH juga dimanfaatkan untuk kegiatan ekonomi produktif seperti penggilingan padi, pengelasan, carpentry, dan berbagai usaha kecil dan menengah di pedesaan. Dengan adanya listrik dari mikrohidro, produktivitas masyarakat meningkat dan kesejahteraan ekonomi membaik secara signifikan. PLTMH juga berkontribusi dalam mengurangi emisi karbon dengan menggantikan penggunaan generator diesel yang selama ini digunakan di daerah terpencil.`,
    history: `Sejarah pengembangan energi mikrohidro di Yogyakarta dimulai pada era 1980-an ketika pemerintah Indonesia meluncurkan program elektrifikasi pedesaan melalui pembangunan PLTMH di berbagai daerah. Pada tahun 1985, PLTMH pertama di Yogyakarta dibangun di Desa Ngargosari, Kecamatan Samigaluh, Kabupaten Kulon Progo dengan kapasitas 10 kW. PLTMH ini memanfaatkan aliran Sungai Progo dan berhasil memberikan listrik kepada sekitar 50 kepala keluarga.

Pada tahun 1990-an, program PLTMH diperluas ke wilayah lereng Gunung Merapi di Kabupaten Sleman. Beberapa desa seperti Ngablak, Giriwungu, dan Tegalmulyo mendapat bantuan pembangunan PLTMH yang memanfaatkan aliran sungai-sungai kecil yang bersumber dari Merapi. Meskipun kapasitasnya kecil (5-15 kW), PLTMH ini memberikan dampak besar bagi masyarakat yang sebelumnya tidak memiliki akses listrik.

Pada tahun 2000-2005, banyak PLTMH yang dibangun pada era sebelumnya mengalami kerusakan dan tidak berfungsi karena kurangnya pemeliharaan dan kapasitas teknis masyarakat. Pemerintah daerah kemudian melakukan program revitalisasi PLTMH dengan memberikan pelatihan operator dan mekanik lokal, serta bantuan suku cadang dan peralatan.

Pada tahun 2007, UGM melalui Pusat Studi Energi melakukan program pendampingan masyarakat dalam pembangunan dan pengelolaan PLTMH secara partisipatif. Pendekatan berbasis masyarakat (community-based) ini terbukti lebih berkelanjutan karena masyarakat merasa memiliki dan bertanggung jawab terhadap keberlangsungan PLTMH.

Pada tahun 2010-2012, dengan dukungan dari Asian Development Bank (ADB) dan Kementerian ESDM, beberapa PLTMH baru dibangun di Kulon Progo dan Gunungkidul dengan kapasitas yang lebih besar (20-50 kW) dan teknologi yang lebih modern. PLTMH-PLTMH ini tidak hanya untuk penerangan tetapi juga untuk mendukung kegiatan ekonomi produktif seperti penggilingan padi dan usaha kecil.

Pada tahun 2014, Desa Hargowilis di Kokap, Kulon Progo menjadi desa percontohan energi terbarukan dengan membangun PLTMH berkapasitas 30 kW yang mampu mensuplai listrik untuk seluruh desa dan bahkan menjual kelebihan listrik ke PLN melalui skema feed-in tariff. Keberhasilan ini menjadi inspirasi bagi desa-desa lain untuk mengembangkan PLTMH.

Pada tahun 2016-2018, program "Desa Mandiri Energi" yang diluncurkan oleh Kementerian ESDM memberikan dukungan signifikan untuk pembangunan PLTMH di Yogyakarta. Beberapa desa di lereng Menoreh dan lereng Merapi mendapat bantuan pembangunan PLTMH lengkap dengan sistem distribusi dan pelatihan manajemen.

Pada tahun 2019, UNY mengembangkan sistem monitoring dan kontrol PLTMH berbasis IoT (Internet of Things) yang memungkinkan operator memantau kinerja PLTMH secara real-time melalui smartphone. Inovasi ini meningkatkan efisiensi operasional dan mempercepat respon terhadap gangguan.

Pada tahun 2020-2021, meskipun terjadi pandemi COVID-19, pembangunan PLTMH terus berlanjut karena dianggap sebagai infrastruktur kritis untuk ketahanan energi dan ekonomi masyarakat pedesaan. Beberapa PLTMH baru dibangun dengan protokol kesehatan yang ketat.

Pada tahun 2022, Pemerintah DIY meluncurkan program "Peta Jalan Mikrohidro Yogyakarta 2022-2030" yang menargetkan pembangunan 50 PLTMH baru dengan total kapasitas 2 MW. Program ini mencakup identifikasi potensi, pendampingan masyarakat, pembangunan infrastruktur, dan pengembangan kelembagaan pengelola PLTMH.

Saat ini, Yogyakarta memiliki sekitar 35 PLTMH yang masih beroperasi dengan total kapasitas terpasang sekitar 800 kW yang melayani lebih dari 3.000 kepala keluarga di daerah terpencil. PLTMH telah mengurangi konsumsi bahan bakar diesel sekitar 50.000 liter per tahun dan mengurangi emisi karbon sekitar 130 ton CO2 per tahun. Pengembangan mikrohidro terus didorong sebagai solusi energi berkelanjutan untuk desa-desa terpencil dan sebagai bagian dari strategi mitigasi perubahan iklim di Yogyakarta.`,
  },
];
