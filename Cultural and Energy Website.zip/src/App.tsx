import { useState, useEffect } from 'react';
import { Music, Volume2, VolumeX, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { HomePage } from './components/HomePage';
import { DetailPage } from './components/DetailPage';

export default function App() {
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);

  useEffect(() => {
    // Load YouTube IFrame API
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    const firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag);

    // Initialize player when API is ready
    (window as any).onYouTubeIframeAPIReady = () => {
      (window as any).player = new (window as any).YT.Player('youtube-player', {
        height: '0',
        width: '0',
        videoId: 'wmGqvKme9mE', // Gamelan Jawa music
        playerVars: {
          autoplay: 0,
          loop: 1,
          playlist: 'wmGqvKme9mE',
          controls: 0,
        },
      });
    };
  }, []);

  const toggleMusic = () => {
    const player = (window as any).player;
    if (player && player.playVideo && player.pauseVideo) {
      if (isMusicPlaying) {
        player.pauseVideo();
      } else {
        player.playVideo();
        player.setVolume(30);
      }
      setIsMusicPlaying(!isMusicPlaying);
    }
  };

  const handleBack = () => {
    setSelectedItem(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-500 via-purple-500 to-indigo-600 relative overflow-hidden">
      {/* Hidden YouTube player */}
      <div id="youtube-player" style={{ display: 'none' }}></div>

      {/* Colorful animated background shapes */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <motion.div
          animate={{
            rotate: 360,
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="absolute -top-20 -left-20 w-64 h-64 bg-gradient-to-br from-yellow-400/30 to-orange-500/30 rounded-full blur-3xl"
        ></motion.div>
        <motion.div
          animate={{
            rotate: -360,
            scale: [1, 1.3, 1],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="absolute top-1/4 -right-20 w-80 h-80 bg-gradient-to-br from-cyan-400/30 to-blue-500/30 rounded-full blur-3xl"
        ></motion.div>
        <motion.div
          animate={{
            rotate: 360,
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="absolute bottom-20 left-1/4 w-72 h-72 bg-gradient-to-br from-green-400/30 to-emerald-500/30 rounded-full blur-3xl"
        ></motion.div>
      </div>

      {/* Animated Wayang Gunungan - Left */}
      <motion.div
        animate={{
          y: [0, -20, 0],
          rotate: [-2, 2, -2],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="fixed left-4 sm:left-8 top-1/4 w-32 sm:w-48 opacity-20 pointer-events-none z-10"
      >
        <img
          src="https://images.unsplash.com/photo-1662792991988-0560b6151a2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxndW51bmdhbiUyMHdheWFuZyUyMGluZG9uZXNpYXxlbnwxfHx8fDE3NjUzMzYxOTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Gunungan"
          className="w-full h-auto drop-shadow-2xl"
        />
      </motion.div>

      {/* Animated Wayang Gunungan - Right */}
      <motion.div
        animate={{
          y: [0, -15, 0],
          rotate: [2, -2, 2],
        }}
        transition={{
          duration: 7,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="fixed right-4 sm:right-8 top-1/3 w-32 sm:w-48 opacity-20 pointer-events-none z-10"
      >
        <img
          src="https://images.unsplash.com/photo-1662792991988-0560b6151a2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxndW51bmdhbiUyMHdheWFuZyUyMGluZG9uZXNpYXxlbnwxfHx8fDE3NjUzMzYxOTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Gunungan"
          className="w-full h-auto drop-shadow-2xl transform scale-x-[-1]"
        />
      </motion.div>

      {/* Animated Wayang Orang - Bottom Left */}
      <motion.div
        animate={{
          x: [-10, 10, -10],
          rotate: [-5, 5, -5],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="fixed left-0 bottom-0 w-48 sm:w-64 opacity-15 pointer-events-none z-10"
      >
        <img
          src="https://images.unsplash.com/photo-1760355714419-ced046db2c99?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXlhbmclMjBrdWxpdCUyMHBlcmZvcm1hbmNlfGVufDF8fHx8MTc2NTMzNjE5MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Wayang Orang"
          className="w-full h-auto drop-shadow-2xl"
        />
      </motion.div>

      {/* Animated Wayang Orang - Bottom Right */}
      <motion.div
        animate={{
          x: [10, -10, 10],
          rotate: [5, -5, 5],
        }}
        transition={{
          duration: 9,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="fixed right-0 bottom-0 w-48 sm:w-64 opacity-15 pointer-events-none z-10"
      >
        <img
          src="https://images.unsplash.com/photo-1760355714419-ced046db2c99?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXlhbmclMjBrdWxpdCUyMHBlcmZvcm1hbmNlfGVufDF8fHx8MTc2NTMzNjE5MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Wayang Orang"
          className="w-full h-auto drop-shadow-2xl transform scale-x-[-1]"
        />
      </motion.div>

      {/* Floating Sparkles */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          animate={{
            y: [0, -100, 0],
            opacity: [0, 1, 0],
            scale: [0, 1, 0],
          }}
          transition={{
            duration: 3 + i,
            repeat: Infinity,
            delay: i * 0.5,
          }}
          className="fixed pointer-events-none z-20"
          style={{
            left: `${10 + i * 15}%`,
            bottom: '10%',
          }}
        >
          <Sparkles className="w-6 h-6 text-yellow-300" />
        </motion.div>
      ))}

      {/* Super Fun Music Button */}
      <motion.button
        whileHover={{ scale: 1.1, rotate: 5 }}
        whileTap={{ scale: 0.9 }}
        onClick={toggleMusic}
        className="fixed top-6 right-6 z-50 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 hover:from-pink-600 hover:via-red-600 hover:to-yellow-600 text-white p-5 rounded-full shadow-2xl transition-all duration-300 flex items-center gap-3 border-4 border-white"
      >
        <AnimatePresence mode="wait">
          {isMusicPlaying ? (
            <motion.div
              key="playing"
              initial={{ rotate: -180, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 180, opacity: 0 }}
              className="flex items-center gap-2"
            >
              <Volume2 className="w-6 h-6" />
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 0.5, repeat: Infinity }}
              >
                <Music className="w-5 h-5" />
              </motion.div>
            </motion.div>
          ) : (
            <motion.div
              key="paused"
              initial={{ rotate: -180, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 180, opacity: 0 }}
            >
              <VolumeX className="w-6 h-6" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Fun Music Visualizer */}
      {isMusicPlaying && (
        <div className="fixed top-24 right-6 z-50 flex gap-1">
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              animate={{
                height: ['10px', '30px', '10px'],
              }}
              transition={{
                duration: 0.5,
                repeat: Infinity,
                delay: i * 0.1,
              }}
              className="w-1 bg-gradient-to-t from-pink-500 to-yellow-400 rounded-full"
            ></motion.div>
          ))}
        </div>
      )}

      {/* Main content */}
      <div className="relative z-30">
        <AnimatePresence mode="wait">
          {selectedItem ? (
            <DetailPage key="detail" itemId={selectedItem} onBack={handleBack} />
          ) : (
            <HomePage key="home" onSelectItem={setSelectedItem} />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
