
  # Cultural and Energy Website

  This is a code bundle for Cultural and Energy Website. The original project is available at https://www.figma.com/design/8jDIh0bJMO0G661pYEAEk5/Cultural-and-Energy-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  